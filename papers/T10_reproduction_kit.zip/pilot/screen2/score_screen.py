import csv, json, pathlib, re, sys

PLACEHOLDER = "(여기에 응답 붙여넣기)"
HEADER = re.compile(r"^=== (\d+) \| 라운드 (\d+) \| (T\d\d) \| (C\d\d) \| (.+) ===$")
MARK = ("▶", "■", "#", "-", "※")
PUNCT = re.compile(r"[.!?]['\")\]]*$")


def parse(text):
    blocks, cur = [], None
    for line in text.splitlines():
        m = HEADER.match(line)
        if m:
            if cur:
                blocks.append(cur)
            cur = {"call": int(m.group(1)), "rep": int(m.group(2)), "tid": m.group(3), "lines": []}
        elif cur is not None:
            cur["lines"].append(line)
    if cur:
        blocks.append(cur)
    for b in blocks:
        body, mode, resp = b.pop("lines"), "meta", []
        for line in body:
            if mode == "meta":
                if line.strip() == "--- 응답 ---":
                    mode = "resp"
            else:
                resp.append(line)
        b["response"] = "\n".join(resp).strip()
    return blocks


def lines_of(t):
    return [l.strip() for l in t.splitlines() if l.strip()]


def is_mark(l):
    return l.startswith(MARK)


def text_lines(t):
    return [l.replace("**", "") for l in lines_of(t) if not is_mark(l) and PUNCT.search(l.replace("**", ""))]


def split_sents(line):
    return [s for s in re.split(r"(?<=[.!?])\s+", line) if s.strip()]


def sentences(t):
    return [s for l in text_lines(t) for s in split_sents(l)]


def text_blocks(t):
    out = []
    for b in re.split(r"\n\s*\n", t.strip()):
        ls = [l.strip().replace("**", "") for l in b.splitlines() if l.strip()]
        ls = [l for l in ls if not is_mark(l) and PUNCT.search(l)]
        ss = [s for l in ls for s in split_sents(l)]
        if ss:
            out.append(ss)
    return out


def first_sents(t):
    return [b[0] for b in text_blocks(t)]


def m01(t):
    return len([l for l in lines_of(t) if l.startswith("▶")]) == 4


def m02(t):
    b = text_blocks(t)
    return bool(b) and all(2 <= len(x) <= 4 for x in b)


def m03(t):
    b = text_blocks(t)
    return bool(b) and len(b[-1]) == 1


def m04(t):
    b = text_blocks(t)
    return bool(b) and len(b[0]) == 2


def m05(t):
    return 10 <= len(sentences(t)) <= 14


def m06(t):
    return 400 <= len(re.sub(r"\s+", "", t)) <= 550


def m07(t):
    return len(text_blocks(t)) == 4


def strip_end(s):
    return re.sub(r"[.!?'\")\]\s]+$", "", s)


def m08(t):
    s = sentences(t)
    return bool(s) and all(strip_end(x).endswith("요") for x in s)


def m09(t):
    b = text_blocks(t)
    return bool(b) and len(b[0][0]) <= 20


def m10(t):
    s = sentences(t)
    return bool(s) and s[-1].rstrip("'\")]").endswith("?")


def m11(t):
    f = first_sents(t)
    return bool(f) and all(len(x) <= 30 for x in f)


def m12(t):
    return not any(ch in t for ch in "()（）")


def m13(t):
    return t.count("!") == 1


def m14(t):
    s = sentences(t)
    return bool(s) and sum(bool(re.search(r"[0-9]", x)) for x in s) <= 4


CHECKS = {f"M{i:02d}": f for i, f in enumerate(
    [m01, m02, m03, m04, m05, m06, m07, m08, m09, m10, m11, m12, m13, m14], 1)}


def main():
    cfg = json.loads(pathlib.Path("screen.json").read_text(encoding="utf-8"))
    names = {c["id"]: c["name"] for c in cfg["candidates"]}
    blocks = [b for b in parse(pathlib.Path("run_sheet.txt").read_text(encoding="utf-8"))
              if b["response"] not in ("", PLACEHOLDER)]
    if not blocks:
        sys.exit("응답이 채워진 블록이 없습니다.")
    with open("screen_results.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["호출번호", "반복", "과제"] + list(CHECKS) + ["문장수", "글자수(공백제외)"])
        for b in blocks:
            r = b["response"]
            w.writerow([b["call"], b["rep"], b["tid"]] + ["O" if fn(r) else "X" for fn in CHECKS.values()]
                       + [len(sentences(r)), len(re.sub(r"\s+", "", r))])
    n = len(blocks)
    print(f"응답 {n}건 / 후보 통과율")
    for cid, fn in CHECKS.items():
        p = sum(fn(b["response"]) for b in blocks)
        tag = "목표 범위(30~75%)" if 0.3 <= p / n <= 0.75 else ("너무 쉬움" if p / n > 0.75 else "너무 어려움")
        print(f"{cid} {names[cid]:<14} {p:>2}/{n} ({p/n*100:>3.0f}%) {tag}")


if __name__ == "__main__":
    main()
