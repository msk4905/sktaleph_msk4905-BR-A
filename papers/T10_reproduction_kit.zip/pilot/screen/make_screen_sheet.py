import json, pathlib, sys
OUT = pathlib.Path("run_sheet.txt")
if OUT.exists():
    sys.exit("run_sheet.txt 가 이미 있어 덮어쓰지 않습니다.")
cfg = json.loads(pathlib.Path("screen.json").read_text(encoding="utf-8"))
chain = " ".join(c["chain"] for c in cfg["candidates"])
lines = [f"# 고정 모델: {cfg['model']}", "# 후보 지시 점검 (기본 조건만)", ""]
n = 0
for rep in range(1, 4):
    for t in cfg["tasks"]:
        n += 1
        lines += [f"=== {n:03d} | 라운드 {rep} | {t['id']} | C00 | 후보 점검 ===",
                  "모델: ", "전환안내: 아니오", "시각: ", "--- 프롬프트 ---",
                  t["intro"] + " " + chain, "--- 응답 ---", "(여기에 응답 붙여넣기)", ""]
OUT.write_text("\n".join(lines), encoding="utf-8")
print(n, "블록 생성")
