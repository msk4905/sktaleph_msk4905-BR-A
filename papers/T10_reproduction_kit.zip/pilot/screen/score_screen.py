import csv, json, pathlib, re, sys

PLACEHOLDER = "(여기에 응답 붙여넣기)"
HEADER = re.compile(r"^=== (\d+) \| 라운드 (\d+) \| (T\d\d) \| (C\d\d) \| (.+) ===$")
MARK = ("▶", "■", "#", "-", "※")
PUNCT = re.compile(r"[.!?]['\")\]]*$")


def parse(text):
    blocks, cur = [], None
    for line in text.splitlines():
        m = HEADER.match(line)
        if m:
            if cur:
                blocks.append(cur)
            cur = {"call": int(m.group(1)), "rep": int(m.group(2)), "tid": m.group(3), "lines": []}
        elif cur is not None:
            cur["lines"].append(line)
    if cur:
        blocks.append(cur)
    for b in blocks:
        body, mode, resp = b.pop("lines"), "meta", []
        for line in body:
            if mode == "meta":
                if line.strip() == "--- 응답 ---":
                    mode = "resp"
            else:
                resp.append(line)
        b["response"] = "\n".join(resp).strip()
    return blocks


def lines_of(t):
    return [l.strip() for l in t.splitlines() if l.strip()]


def is_mark(l):
    return l.startswith(MARK)


def text_lines(t):
    return [l.replace("**", "") for l in lines_of(t) if not is_mark(l) and PUNCT.search(l.replace("**", ""))]


def split_sents(line):
    return [s for s in re.split(r"(?<=[.!?])\s+", line) if s.strip()]


def sentences(t):
    return [s for l in text_lines(t) for s in split_sents(l)]


def text_blocks(t):
    out = []
    for b in re.split(r"\n\s*\n", t.strip()):
        ls = [l.strip().replace("**", "") for l in b.splitlines() if l.strip()]
        ls = [l for l in ls if not is_mark(l) and PUNCT.search(l)]
        ss = [s for l in ls for s in split_sents(l)]
        if ss:
            out.append(ss)
    return out


def k01(t):
    return re.search(r"(?<![가-힣])(그리고|또한|따라서|그러므로|하지만)(?![가-힣])", t) is None


def k02(t):
    s = [x.split()[0] for x in sentences(t)]
    return all(a != b for a, b in zip(s, s[1:]))


def k03(t):
    s = sentences(t)
    return bool(s) and sum(len(x) >= 25 for x in s) / len(s) >= 0.5


def k04(t):
    return "," not in t and "，" not in t


def k05(t):
    return len([l for l in lines_of(t) if l.startswith("▶")]) == 4


def k06(t):
    b = text_blocks(t)
    return bool(b) and all(2 <= len(x) <= 4 for x in b)


def k07(t):
    s = sentences(t)
    return bool(s) and all(15 <= len(x) <= 50 for x in s)


def k08(t):
    return len([l for l in lines_of(t) if re.match(r"-\s", l)]) == 5


def k09(t):
    b = text_blocks(t)
    return bool(b) and len(b[-1]) == 1


def k10(t):
    b = text_blocks(t)
    return bool(b) and len(b[0]) == 2


def k11(t):
    return 30 <= len(sentences(t)) <= 40


def k12(t):
    return "**" not in t and "#" not in t and "`" not in t


def k13(t):
    return len([l for l in lines_of(t) if l.startswith("※")]) == 2


def k14(t):
    return not any(ch in t for ch in ['"', "“", "”"])


CHECKS = {f"K{i:02d}": f for i, f in enumerate(
    [k01, k02, k03, k04, k05, k06, k07, k08, k09, k10, k11, k12, k13, k14], 1)}


def main():
    cfg = json.loads(pathlib.Path("screen.json").read_text(encoding="utf-8"))
    names = {c["id"]: c["name"] for c in cfg["candidates"]}
    blocks = [b for b in parse(pathlib.Path("run_sheet.txt").read_text(encoding="utf-8"))
              if b["response"] not in ("", PLACEHOLDER)]
    if not blocks:
        sys.exit("응답이 채워진 블록이 없습니다.")
    with open("screen_results.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["호출번호", "반복", "과제"] + list(CHECKS) + ["문장수", "글자수(공백제외)"])
        for b in blocks:
            r = b["response"]
            w.writerow([b["call"], b["rep"], b["tid"]] + ["O" if fn(r) else "X" for fn in CHECKS.values()]
                       + [len(sentences(r)), len(re.sub(r"\s+", "", r))])
    n = len(blocks)
    print(f"응답 {n}건 / 후보 통과율")
    for cid, fn in CHECKS.items():
        p = sum(fn(b["response"]) for b in blocks)
        tag = "목표 범위(30~75%)" if 0.3 <= p / n <= 0.75 else ("너무 쉬움" if p / n > 0.75 else "너무 어려움")
        print(f"{cid} {names[cid]:<14} {p:>2}/{n} ({p/n*100:>3.0f}%) {tag}")


if __name__ == "__main__":
    main()
