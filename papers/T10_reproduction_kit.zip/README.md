# 재현 꾸러미 — 프롬프트의 구조적 요소와 AI의 지시 준수율

## 구성
- paper/프롬프트의_구조적_요소가_AI의_지시_준수율에_미치는_영향.docx : 논문 원고 (그림 fig1.png, fig2.png, 원고 생성 스크립트 build_paper.js 포함)
- data/set1~3/run_sheet.txt : 실제 사용한 원자료. 세트당 100회 응답, 총 300회 (gemini-3.5-flash-lite 응답 원문)
- code/conditions.json : 과제 10개·조건 10개·지시 8개 전체 정의 (고정)
- code/make_run_sheet.py : 실행 기록 틀 생성 (세트 시드 20/21/22)
- code/run_gemini.py : Gemini API 호출 (환경변수 GEMINI_API_KEY 필요, 호출당 6초 간격)
- code/run_openai.py : OpenAI API 호출 (환경변수 OPENAI_API_KEY 필요)
- code/score.py : 문자열 규칙 채점
- code/analyze.py : 통계 분석(짝지은 차이, 부트스트랩 20,000회·시드 10, 순열검정 20,000회, Holm, Fisher)과 표·그림 생성
- results/ : results_all.csv, summary_final.csv, per_rule.csv, per_task.csv, fig1.png, fig2.png
- ext/ : 반복·보강 실험의 원자료·스크립트·결과. Gemini 쪽(주 실험 반복 R, 예시 변형 V, 다른 모델 M_m2, 어긋나는 예시 X, 다른 글 종류 S, 예시의 길이 통제 L, 다른 예시 E)과 OpenAI 쪽(gpt-6-luna 아홉 요소 R_gpt6, 지시 12개 D_gpt6, 다른 예시 E_gpt6, 기본·예시 M_gpt6·M_gpt, 어긋나는 예시 X_gpt6, 다른 글 종류 S_gpt6), 내용 점검(Q, 사실 점검 F)이 들어 있다. 자세한 내용은 ext/README.md.
- pilot/ : 예비 실험·선별 실험 원자료와 스크립트 (논문 부록 D 표 D1)

## 재현 방법
1. 분석만 다시 하기 (키 불필요): 이 폴더에서 `python code/analyze.py`
   - 필요: Python 3 (표준 라이브러리만 사용). 그림을 다시 만들려면 matplotlib (한글 글꼴: Noto Sans CJK KR)
   - results/ 의 표와 그림이 같은 값으로 다시 만들어진다.
2. 호출부터 다시 하기: 환경변수 GEMINI_API_KEY 설정 → 새 폴더에서 `python code/make_run_sheet.py` 로 빈 run_sheet 생성 → `python code/run_gemini.py --model gemini-3.5-flash-lite` (중단돼도 이어서 실행됨).
   - 모델 응답은 호출마다 달라 숫자가 똑같이 나오지 않는다. 논문의 숫자는 data/ 의 응답 기준이다.
3. 반복·보강 실험 분석 (키 불필요): `python ext/code/analyze_ext.py`, `python ext/code/analyze_x.py`, `python ext/code/analyze_facts.py`, `python ext/code/content_check.py`

4. 논문 원고 다시 만들기: `cd paper && node build_paper.js` (docx 패키지 필요: `npm install docx`)
