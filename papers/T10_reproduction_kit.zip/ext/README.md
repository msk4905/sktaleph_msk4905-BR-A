# 반복 및 보강 실험

주 실험(300회, data/set1~3)을 마친 뒤 한계를 줄이려고 한 실험이다. 설계, 분량, 판정 기준은 해당 데이터를 얻기 전에 정했고, 정한 분량은 결과와 상관없이 전부 수행해 모두 보고했다.
단, content_check.py(내용 보존 점검)는 Q 결과를 본 뒤에 추가한 사후 분석이다.

## 실험
- R (주 실험 반복, gemini-3.5-flash-lite): 주 실험과 같은 10개 조건. 세트 4~10, 7세트 x 10과제 x 10조건 = 700회. 분석은 R(반복만)과 ALL(주 실험 세트 1~3 + R, 10세트, 조건당 100쌍) 두 가지.
- V (예시 변형, gemini-3.5-flash-lite): 기본 C00 / 예시 1개 C04 / 예시 2개 V2 / 형식 틀 V3(내용 없는 빈칸 틀). 12세트 x 10과제 x 4조건 = 480회. 예시 1개(C04)와의 직접 비교도 한다.
- M_m2 (다른 모델 반복, gemini-3.1-flash-lite): 기본 C00 / 예시 C04. 10세트 x 10과제 x 2조건 = 200회.
- M_gpt6 (OpenAI API, gpt-6-luna, 주 결과): 기본 C00 / 예시 C04. 20세트 x 10과제 x 2조건 = 400회.
- M_gpt (OpenAI API, gpt-5.6-luna, 비교 결과): 기본 C00 / 예시 C04. 30세트 x 10과제 x 2조건 = 600회. 두 GPT 모델은 섞지 않고 따로 분석한다. 추론 강도 등 다른 설정은 기본값(최대 출력 토큰만 32,000).
- E (다른 예시, gemini-3.5-flash-lite; E_gpt6은 gpt-6-luna 400회, 아래 7차 참고): 기본 C00 / 도서관 예시 C04 / 다른 예시 E1(헌 옷 수거, 12문장) / 다른 예시 E2(분리배출, 10문장). 10세트 x 10과제 x 4조건 = 400회. 아래 6차 추가 실험 참고.
- Q (내용 질, 심판 gemma-4-26b-a4b-it): 주 실험의 C00 vs C04 응답을 같은 과제끼리 짝지어(30짝) A/B 위치를 바꿔 2번씩, 총 60회. 호출 없이 예시 글과 겹치는 6글자 조각 비율도 잰다.
- M_m1: 모델 문제로 수집하지 않은 빈 시트. 분석에 쓰지 않는다.

## 판정 기준
- R, V, M, G: 주 실험과 같다(짝지은 차이의 95% 부트스트랩 구간 20,000회, 순열검정 20,000회, 시드 10, Holm 보정, 10%p 이하이면 "기본과 구분되지 않음").
- Q: C04 승률의 95% 구간 상한이 50% 미만이면 "예시가 내용 질을 낮춤", 구간이 50%를 포함하면 "낮춘다는 증거 없음", 하한이 50% 초과이면 "높임".

## 폴더
- data/R_set4~10, data/V_set1~12, data/M_m2_set1~10, data/M_gpt_set1~30, data/M_gpt6_set1~20 : 채워진 run_sheet.txt (응답 원문)
- data/Q/judgments.jsonl : 심판 판정 60건
- code/ : make_ext_sheet.py(시트 생성), run_ext.py(호출), judge_quality.py(심판), analyze_ext.py(분석), content_check.py(내용 보존 점검), progress.py(진행률)
- results/ : 분석 결과 표 (R, ALL, V, E, E_gpt6, M_m2, M_gpt, M_gpt6, Q, content_check)

## 다시 분석하기 (키 불필요, 꾸러미 최상위 폴더에서)
python ext/code/analyze_ext.py
python ext/code/content_check.py

## 다시 호출하기
시트의 응답을 비운 폴더가 필요하다(make_ext_sheet.py 로 새로 만든다). 이미 채워진 응답은 건너뛰고, 같은 시트를 두 창에서 동시에 실행하지 않는다.
Gemini 파트는 환경변수 GEMINI_API_KEY, OpenAI 파트는 OPENAI_API_KEY 와 --api openai 가 필요하다.
python ext/code/run_ext.py --part R --model gemini-3.5-flash-lite --limit 700
python ext/code/run_ext.py --part V --model gemini-3.5-flash-lite --limit 240
python ext/code/run_ext.py --part M_m2 --model gemini-3.1-flash-lite --limit 100
python ext/code/run_ext.py --part M_gpt6 --api openai --model gpt-6-luna --limit 400
python ext/code/run_ext.py --part M_gpt --api openai --model gpt-5.6-luna --limit 400
python ext/code/judge_quality.py --model gemma-4-26b-a4b-it --limit 60
- 진행률: python ext/code/progress.py --watch
- 무료 하루 한도와 모델 상태에 따라 같은 호출이 그대로 되지 않을 수 있고, 응답은 호출마다 달라진다.

## 2차 추가 실험 (결과를 보기 전에 분량과 판정 기준을 고정)
1. G6 (두 번째 주 모델, R_gpt6): gpt-6-luna에서 주 실험과 같은 10개 조건. 세트 10개 x 10과제 x 10조건 = 1,000회. 주 실험과 같은 통계(짝지은 차이, 부트스트랩 구간, 순열검정, Holm, 10%p 기준). 지시와 조건은 주 실험과 똑같이 두고 이 모델에 맞춰 조정하지 않는다. 기본 점수가 높아(이미 96% 안팎) 개선 여지가 작을 수 있으며, 이는 결과와 함께 보고한다.
2. X, X_gpt6 (어긋나는 예시, gemini-3.5-flash-lite와 gpt-6-luna): 기본 C00 / 예시 1개 C04 / 정상 예시(중립 안내) N0 / 구조 어긋난 예시 X1(소제목·문단 5개) / 문체 어긋난 예시 X2(합니다체). 모델마다 10세트 x 10과제 x 5조건 = 500회. N0, X1, X2는 같은 중립 안내문("예시(내용은 다른 글이야):")을 쓴다. 충돌 지시는 X1이 지시1(소제목 4줄)·지시2(문단 4개), X2가 지시7(해요체)이다.
   - 핵심 지표: 충돌 지시 통과율. 판정은 analyze_x.py 머리말에 적어 두었다(X-N0 차이 D: 구간 상한 0 미만이고 D <= -10%p이면 "예시 우선", D > -10%p이면 "지시 우선", 그 사이는 "혼합").
   - 보조: 어긋난 예시를 그대로 따라 쓴 응답 비율, 충돌하지 않는 나머지 지시의 통과율.
3. F (사실 점검): 응답마다 요청에 있던 사실의 포함 여부, 지어낸 사실 수, 어조, 자연스러움을 다른 회사 모델이 판정한다(facts.json에 과제별 사실 목록). gemini-3.5-flash-lite 응답 200건(기본·예시, 10세트)은 gpt-6-luna가, gpt-6-luna 응답 200건(세트 1~10)은 gemini-3.5-flash-lite가 판정한다. 판정: 사실 보존율 차이(C04-C00)의 구간 상한이 0 미만이면 "예시가 사실 보존을 낮춤".

```
python ext/code/run_ext.py --part R_gpt6 --api openai --model gpt-6-luna --limit 1000
python ext/code/run_ext.py --part X --model gemini-3.5-flash-lite --limit 500
python ext/code/run_ext.py --part X_gpt6 --api openai --model gpt-6-luna --limit 500
python ext/code/judge_facts.py --target ALL --api openai --model gpt-6-luna --limit 200
python ext/code/judge_facts.py --target GPT6 --api gemini --model gemini-3.5-flash-lite --limit 200
python ext/code/analyze_ext.py        (R_gpt6 표 포함)
python ext/code/analyze_x.py
python ext/code/analyze_facts.py
```
- 진행률: python ext/code/progress.py --watch


## 3차 추가 실험: 다른 글 종류 과제 (S, 사전 확정)
- 목적: 주 실험의 과제 10개와 다른 글 종류에서도 같은 방향인지 본다.
- 과제 8개(T11~T18, `ext/code/tasks_S.json`): 뉴스 요약문, 과학 개념 설명글, 북토크 후기, 설득하는 글, 하루 일기, 동아리 지원 동기, 발표 원고, 짧은 동화. 규칙 8개와 예시(도서관 이용 안내)는 주 실험과 똑같다.
- 조건은 기본 C00과 예시 1개 C04 두 가지다. 한 세트 = 과제 8개 x 2조건 = 16회.
- S_gpt6 (gpt-6-luna): 20세트 = 320회 (시드 161~180). S (gemini-3.5-flash-lite): 10세트 = 160회 (시드 151~160).
- 분석은 M 부분과 같다(같은 세트·라운드끼리 짝지은 차이, 부트스트랩 95% 구간, 순열검정, 10%p 기준). 과제별 결과는 탐색용으로만 본다.
- 호출 횟수와 과제는 결과를 보기 전에 정했다.

```
python ext/code/run_ext.py --part S_gpt6 --api openai --model gpt-6-luna --limit 320
python ext/code/run_ext.py --part S --model gemini-3.5-flash-lite --limit 160
python ext/code/analyze_ext.py
```


## 4차 추가 실험: 예시의 길이 통제 (L, 사전 확정)
- 목적: 예시 제시의 효과가 "프롬프트가 길어져서"나 "도서관 안내 내용을 봐서"가 아니라 규칙을 지킨 형식을 보여 줘서인지 가른다.
- 조건 4개(Gemini gemini-3.5-flash-lite만): 기본 C00 / 예시 1개 C04 / L1 같은 길이 줄글 / L2 같은 길이 무관한 글.
  - L1: 예시와 같은 내용·같은 해요체 문장을 소제목·문단 구분 없이 한 덩어리 줄글로 쓴 글(233자, 예시 238자). 느낌표는 예시처럼 1번.
  - L2: 한국의 사계절을 합니다체로 쓴 무관한 줄글(239자). 느낌표 없음.
  - L1, L2는 "참고 글:"이라는 중립 안내를 쓴다(C04의 "위 지시를 모두 지킨 글"이라는 말을 쓰지 않는다).
- 한 세트 = 과제 10개 x 4조건 = 40회. 세트 10개(시드 181~190) = 400회. 분량은 결과를 보기 전에 정했다.
- 분석은 M 부분과 같다(같은 세트·라운드끼리 짝지은 차이). 판정은 analyze_ext.py에 적어 두었다: 통제-예시 차이의 구간 상한이 0 미만이고 -10%p 이하이면 "예시가 더 높음(길이·내용만으로 설명되지 않음)", 통제-기본이 10%p 초과이고 구간 하한이 0 초과이면 "통제 글도 효과가 있음", 그 밖은 "혼합". 지시별 결과(per_rule)도 함께 본다(L1은 해요체 문체 단서를 함께 줄 수 있다).

```
python ext/code/run_ext.py --part L --model gemini-3.5-flash-lite --limit 400
python ext/code/analyze_ext.py
```

## 5차 추가 실험: 어려운 지시 (D_gpt6)
- 목적: gpt-6-luna는 기본 준수율이 96.9%로 천장에 가까워 요소별 차이를 구분할 여지가 작았다. 지시를 8개에서 12개로 늘려 기본 준수율이 낮아진 상태에서 요소 차이가 구분되는지 본다. (낮아질지는 결과를 보기 전에는 알 수 없다.)
- 과제: tasks_D.json(`python ext/code/make_tasks_D.py`로 생성). 글 종류는 T11~T18과 같고 번호만 T21~T28이다. 기존 8개 지시에 4개를 더했다: 물음표 정확히 1회, '그리고'/'그래서'/'또한' 금지, 모든 문장 40자 이내, 문장 끝 두 글자가 같은 문장 3연속 금지. 예시(C04)는 12개 지시를 모두 지키도록 다시 썼고 생성 시 자동 확인한다. 과제 설명 중 '그래서'가 들어 있던 한 곳만 '덕분에'로 바꿨다.
- 조건: 주 실험과 같은 10개 조건(C00~C09). 한 세트 = 과제 8개 x 10조건 = 80회, 8세트(시드 201~208) = 640회. 양과 판정 방식은 결과를 보기 전에 정했다.
- 실행: `python ext/code/run_ext.py --part D_gpt6 --api openai --model gpt-6-luna --limit 640`
- 분석: `python ext/code/analyze_ext.py` → `ext/results/D_gpt6_summary.csv`, `D_gpt6_per_rule.csv` (분석 방식은 R_gpt6과 같다: 짝지은 차이, 부트스트랩, 순열검정, Holm, 10%p 기준)

## 6차 추가 실험: 다른 예시 (E, 사전 확정)
- 목적: 논문의 예시 제시 조건은 도서관 이용 안내라는 예시 하나를 모든 과제에 썼다. 주제와 문장 구성이 다른 예시에서도 같은 효과가 나는지 본다.
- 조건 4개(Gemini gemini-3.5-flash-lite만): 기본 C00 / 예시 1개 C04(도서관 이용 안내, 10문장) / E1 다른 예시 A / E2 다른 예시 B. 세 예시 모두 8개 지시를 모두 지킨 글이고 같은 안내문("예시(내용은 다르지만 위 지시를 모두 지킨 글이야):")을 쓴다. 생성 시 score.py의 규칙으로 통과를 확인했다.
  - E1: 헌 옷 수거 안내, 12문장(문단별 2/3/4/3). 전체 문장 수 범위(10~14)의 가운데다.
  - E2: 분리배출 안내, 10문장(문단별 2/3/3/2). C04와 문장 구성은 같고 주제만 다르다.
- 한 세트 = 과제 10개 x 4조건 = 40회. 세트 10개(시드 211~220) = 400회. 분량은 결과를 보기 전에 정했다.
- 분석은 M 부분과 같다(같은 세트·라운드끼리 짝지은 차이, 부트스트랩 구간, 순열검정, Holm, 10%p). 사전 판정: E1, E2 각각 기본 대비 차이가 10%p 초과이고 구간 하한이 0 초과이면 "효과 유지", 그 밖은 "효과 불분명". C04와의 직접 비교와 지시별 결과(per_rule)는 탐색용으로 함께 본다. 특히 전체 10~14문장 지시가 12문장 예시(E1)에서 C04보다 높은지는 탐색용 관찰이다.

```
python ext/code/run_ext.py --part E --model gemini-3.5-flash-lite --limit 400
python ext/code/analyze_ext.py
```

## 7차 추가 실험: 다른 예시, gpt-6-luna (E_gpt6, 사전 확정)
- 목적: 6차 실험(E)을 주 모델의 하나인 gpt-6-luna에서도 같은 방식으로 한다. gpt-6-luna는 기본 준수율이 96~97%여서 천장에 가까울 것으로 예상하지만, 예상일 뿐이고 결과와 상관없이 전부 보고한다.
- 조건·예시·판정 기준·통계 방식은 6차(E)와 같다(기본 C00 / 도서관 예시 C04 / E1 헌 옷 수거 12문장 / E2 분리배출 10문장).
- 한 세트 = 과제 10개 x 4조건 = 40회. 세트 10개(시드 221~230) = 400회.
- 호출은 OpenAI Responses API, 설정은 다른 gpt-6-luna 실험과 같다(기본값, 최대 출력 토큰 32,000).

```
python ext/code/run_ext.py --part E_gpt6 --api openai --model gpt-6-luna --limit 400
python ext/code/analyze_ext.py
```
