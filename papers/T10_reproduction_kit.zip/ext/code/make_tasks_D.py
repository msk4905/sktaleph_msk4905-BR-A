"""어려운 지시(D) 과제 파일 tasks_D.json 생성.  python ext/code/make_tasks_D.py
tasks_S.json 의 8개 글 종류(T11~T18)를 T21~T28 로 옮기고, 지시를 8개 -> 12개로 늘린다(예시도 12개를 모두 지키도록 다시 썼다).
"""
import json
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent.parent / "code"))
import score  # noqa: E402

EXAMPLE = (
    "▶ 도서관 이용 안내\n"
    "이번 달부터 도서관이 달라져요. 열람실 운영 시간과 대출 방법이 조금 바뀌었어요.\n\n"
    "▶ 운영 시간\n"
    "평일에는 오전 9시에 문을 열어요. 저녁 8시까지 조용한 열람실을 이용할 수 있어요. 주말에는 오후 6시에 일찍 닫아요.\n\n"
    "▶ 대출 방법\n"
    "책은 한 번에 다섯 권까지 빌릴 수 있어요. 대출 기간은 2주예요! 기간이 끝나기 전에 연장도 할 수 있나요? 물론 가능해요.\n\n"
    "▶ 문의\n"
    "궁금한 점은 안내 데스크에 편하게 물어보세요. 전화로도 문의하실 수 있고 누리집에도 안내가 올라와 있어요."
)
NEW_RULES = [
    {"chain": "물음표(?)는 전체에서 정확히 한 번만 쓰고,", "list": "물음표(?)는 전체에서 정확히 한 번만 쓴다",
     "checks": [{"type": "count_equals", "item": "?", "n": 1}]},
    {"chain": "'그리고', '그래서', '또한'은 쓰지 않고,", "list": "'그리고', '그래서', '또한'은 쓰지 않는다",
     "checks": [{"type": "not_contains", "items": ["그리고", "그래서", "또한"]}]},
    {"chain": "모든 문장은 공백 포함 40자 이내로 쓰고,", "list": "모든 문장은 공백 포함 40자 이내로 쓴다",
     "checks": [{"type": "max_sentence_len", "n": 40}]},
    {"chain": "문장 끝 두 글자가 같은 문장은 세 번 연속 쓰지 않도록 써 줘.",
     "list": "문장 끝 두 글자가 같은 문장은 세 번 연속 쓰지 않는다",
     "checks": [{"type": "no_repeat_ending", "n": 3}]},
]


def build():
    src = json.loads((HERE / "tasks_S.json").read_text(encoding="utf-8"))["tasks"]
    out = []
    for i, t in enumerate(src):
        t = json.loads(json.dumps(t))
        t["id"] = f"T{21 + i}"
        t["intro"] = t["intro"].replace("그래서 하루에", "덕분에 하루에")  # 금지어('그래서')가 과제 설명에 들어 있던 한 곳
        t["rules"][-1]["chain"] = t["rules"][-1]["chain"].replace("써 줘.", "쓰고,")
        t["rules"] += json.loads(json.dumps(NEW_RULES))
        t["example"] = EXAMPLE
        out.append(t)
    return out


if __name__ == "__main__":
    tasks = build()
    t0 = tasks[0]
    fails = [r["list"] for r in t0["rules"] if not score.rule_pass(r, EXAMPLE)]
    print("예시가 어기는 지시:", fails, "/ 지시 수:", len(t0["rules"]))
    if fails:
        sys.exit("예시가 모든 지시를 지키지 않습니다.")
    (HERE / "tasks_D.json").write_text(json.dumps({"tasks": tasks}, ensure_ascii=False, indent=1), encoding="utf-8")
    print("tasks_D.json 저장:", len(tasks), "개 과제")
