"""보강 실험 호출. data/ 안의 폴더를 순서대로 채운다(이어서 하기 가능).

  python code/run_ext.py --part V --model gemini-3.5-flash-lite --limit 100
  python code/run_ext.py --part M_gpt --api openai --model gpt-5.6-luna --limit 60
  python code/run_ext.py --part M_m1 --model 모델ID --limit 100
환경변수 GEMINI_API_KEY(--api openai 이면 OPENAI_API_KEY) 필요. --limit 은 이번 실행에서 호출할 최대 횟수(하루 한도 관리용).
"""
import argparse
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent

ap = argparse.ArgumentParser()
ap.add_argument("--part", required=True, help="V, M_m1, M_m2, M_gpt")
ap.add_argument("--model", required=True)
ap.add_argument("--limit", type=int, default=100)
ap.add_argument("--api", choices=["gemini", "openai"], default="gemini")
a = ap.parse_args()
RUN = ROOT.parent / "code" / f"run_{a.api}.py"
left = a.limit
for d in sorted((ROOT / "data").glob(f"{a.part}_set*")):
    if left <= 0:
        break
    print(f"== {d.name} ==", flush=True)
    p = subprocess.Popen([sys.executable, "-u", str(RUN), "--model", a.model, "--limit", str(left)],
                         cwd=d, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                         encoding="utf-8", errors="replace")
    out = ""
    for line in p.stdout:
        print(line, end="", flush=True)
        out += line
    p.wait()
    m = re.search(r"이번 실행에서 (\d+)건 저장", out)
    n = int(m.group(1)) if m else 0
    left -= n
    if "실패" in out:
        break
print("남은 한도:", left)
