"""어긋나는 예시(X, X_gpt6) 분석.  python ext/code/analyze_x.py   (꾸러미 최상위 폴더에서, 키 불필요)

조건: C00 기본 / C04 예시 1개 / N0 정상 예시(중립 안내) / X1 구조 어긋난 예시(소제목·문단 5개) / X2 문체 어긋난 예시(합니다체)
충돌 지시: X1 -> 지시1 소제목 4줄, 지시2 문단 4개 / X2 -> 지시7 해요체
핵심 지표: 충돌 지시 통과율. 같은 (세트,라운드)끼리 짝지어 부트스트랩 95% 구간(20,000회, 시드 10)을 구한다.
판정(결과를 보기 전에 정함, X - N0 의 충돌 지시 통과율 차이 D 기준):
  구간 상한이 0 미만이고 D <= -10%p : "예시 우선" (예시가 지시를 이김)
  D > -10%p                          : "지시 우선" (예시와 어긋나도 지시를 따름)
  그 사이                            : "혼합"
추가로 X 의 충돌 지시 통과율이 기본(C00)보다 10%p 넘게 낮으면 "예시 때문에 기본보다 더 어김"으로 따로 적는다.
"""
import csv
import pathlib
import random
import statistics as st
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import analyze_ext as ae  # noqa: E402

CONF = {"X1": [0, 1], "X2": [6]}
NAME = {"X1": "구조 어긋남(소제목·문단 5개)", "X2": "문체 어긋남(합니다체)"}
rate = lambda v: sum(v) / len(v) * 100


def boot(d, rng, nb=20000):
    m = st.mean(d)
    bs = sorted(st.mean(rng.choices(d, k=len(d))) for _ in range(nb))
    return m, bs[int(nb * .025)], bs[int(nb * .975)]


def copied(cid, resp):
    if cid == "X1":
        return sum(1 for l in resp.split("\n") if l.strip().startswith("▶")) == 5
    sents = [x for x in ae.score.sentences(resp) if not x.startswith("▶")]
    if not sents:
        return False
    tail = sum(1 for x in sents if x.rstrip(" .!?\"'”’)").endswith(("니다", "십시오")))
    return tail / len(sents) >= 0.5


def main():
    rows = []
    for part in ("X", "X_gpt6"):
        runs = ae.load(part)
        if not runs:
            print(f"[{part}] 아직 모든 응답이 채워지지 않아 건너뜁니다.")
            continue
        cell = {(r["set"], r["round"], r["cid"]): r for r in runs}
        keys = sorted({(s, rd) for s, rd, _ in cell})
        rng = random.Random(10)
        model = "/".join(sorted({r["model"] for r in runs}))
        print(f"[{part}] 모델 {model} / 짝 {len(keys)}")
        for x, idx in CONF.items():
            sub = lambda c, k: rate([cell[(*k, c)]["checks"][i] for i in idx])
            oth = [i for i in range(8) if i not in idx]
            subo = lambda c, k: rate([cell[(*k, c)]["checks"][i] for i in oth])
            d_n0 = [sub(x, k) - sub("N0", k) for k in keys]
            d_c0 = [sub(x, k) - sub("C00", k) for k in keys]
            do_n0 = [subo(x, k) - subo("N0", k) for k in keys]
            m, lo, hi = boot(d_n0, rng)
            m0, lo0, hi0 = boot(d_c0, rng)
            mo, loo, hio = boot(do_n0, rng)
            verdict = "예시 우선" if (hi < 0 and m <= -10) else ("지시 우선" if m > -10 else "혼합")
            extra = "예시 때문에 기본보다 더 어김" if m0 < -10 else ""
            cp = sum(copied(x, cell[(*k, x)]["resp"]) for k in keys) / len(keys) * 100
            vals = {c: st.mean(sub(c, k) for k in keys) for c in ("C00", "C04", "N0", x)}
            valso = {c: st.mean(subo(c, k) for k in keys) for c in ("C00", "C04", "N0", x)}
            rows.append([part, model, x, NAME[x], len(keys),
                         f"{vals['C00']:.1f}", f"{vals['C04']:.1f}", f"{vals['N0']:.1f}", f"{vals[x]:.1f}",
                         f"{m:+.1f}", f"{lo:+.1f}", f"{hi:+.1f}", f"{m0:+.1f}", f"{lo0:+.1f}", f"{hi0:+.1f}",
                         f"{cp:.1f}", verdict, extra,
                         f"{valso['C00']:.1f}", f"{valso['C04']:.1f}", f"{valso['N0']:.1f}", f"{valso[x]:.1f}",
                         f"{mo:+.1f}", f"{loo:+.1f}", f"{hio:+.1f}"])
            print(f"  {x} {NAME[x]}: 충돌 지시 통과율 기본 {vals['C00']:.1f} / 예시 {vals['C04']:.1f} / 정상예시 {vals['N0']:.1f} / {x} {vals[x]:.1f}"
                  f"  | X-N0 {m:+.1f}%p [{lo:+.1f},{hi:+.1f}] -> {verdict} {extra}  | 예시를 따라 쓴 비율 {cp:.1f}%"
                  f"  | 나머지 지시 X-N0 {mo:+.1f}%p [{loo:+.1f},{hio:+.1f}]")
    if rows:
        with open(ae.OUT / "X_conflict.csv", "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["파트", "모델", "조건", "충돌 유형", "짝 수",
                        "충돌 지시 통과율: 기본", "예시 1개", "정상 예시", "어긋난 예시",
                        "X-정상예시(%p)", "하한", "상한", "X-기본(%p)", "하한", "상한",
                        "예시를 따라 쓴 비율(%)", "판정", "비고",
                        "나머지 지시 통과율: 기본", "예시 1개", "정상 예시", "어긋난 예시",
                        "나머지 X-정상예시(%p)", "하한", "상한"])
            w.writerows(rows)


if __name__ == "__main__":
    main()
