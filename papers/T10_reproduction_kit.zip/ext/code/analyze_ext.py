"""보강 실험 분석.  python code/analyze_ext.py   (ext/ 폴더 기준, 결과는 ext/results/)
 V, M_m1, M_m2, M_gpt : 조건별 지시 준수율을 기본(C00)과 같은 (세트,라운드)끼리 짝지어 비교
                 (부트스트랩 95% 구간 20,000회, 순열검정 20,000회, 시드 10, Holm, 10%p 기준)
 Q             : 예시(C04)와 기본(C00)의 내용 질 승률, 그리고 예시 베끼기 정도(예시와 겹치는 6글자 조각 비율)
아직 채워지지 않은 부분은 건너뛴다.
"""
import csv
import json
import pathlib
import random
import re
import statistics as st
import sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
MAIN = ROOT.parent / "code"
sys.path.insert(0, str(MAIN))
import score  # noqa: E402

SEED, NB, NP, TH = 10, 20000, 20000, 10.0
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)
CFG = json.loads((MAIN / "conditions.json").read_text(encoding="utf-8"))
TASKS = {t["id"]: t for t in CFG["tasks"]}
TASKS.update({t["id"]: t for t in json.loads((HERE / "tasks_S.json").read_text(encoding="utf-8"))["tasks"]})
TASKS.update({t["id"]: t for t in json.loads((HERE / "tasks_D.json").read_text(encoding="utf-8"))["tasks"]})
NAMES = {c["id"]: c["name"] for c in CFG["conditions"]}
NAMES.update({"C04": "예시 1개", "V2": "예시 2개", "V3": "형식 틀", "N0": "정상 예시(중립 안내)",
              "X1": "구조 어긋난 예시", "X2": "문체 어긋난 예시",
              "L1": "같은 길이 줄글(예시와 같은 내용)", "L2": "같은 길이 무관한 글",
              "E1": "다른 예시 A(12문장)", "E2": "다른 예시 B(10문장)"})
NAMES_R = {c["id"]: c["name"] for c in CFG["conditions"]}
RULES = ["소제목 4줄", "문단 4개", "첫 문단 2문장", "느낌표 1회", "문단당 2~4문장",
         "전체 10~14문장", "해요체", "첫 문장 20자 이내"]
RULES_D = RULES + ["물음표 1회", "금지어 3개 없음", "모든 문장 40자 이내", "같은 끝 두 글자 3연속 없음"]
rate = lambda v: sum(v) / len(v) * 100


def load(part):
    runs = []
    skipped = []
    if part == "ALL":  # 주 실험 세트 1~3 + 반복 세트 R(4~10)
        dirs = [MAIN.parent / "data" / f"set{i}" for i in (1, 2, 3)] + sorted((ROOT / "data").glob("R_set*"))
    else:
        dirs = sorted((ROOT / "data").glob(f"{part}_set*"))
    for d in dirs:
        s = int(d.name.rsplit("set", 1)[1])
        blocks = score.parse((d / "run_sheet.txt").read_text(encoding="utf-8"))
        if any(b["response"] in ("", score.PLACEHOLDER) for b in blocks):
            skipped.append(s)  # 빈 호출이 있는 세트는 통째로 제외(짝이 깨지지 않게)
            continue
        for b in blocks:
            if b["meta"]["전환안내"] in ("예", "y", "Y", "yes"):
                continue
            ch = [score.rule_pass(r, b["response"]) for r in TASKS[b["tid"]]["rules"]]
            runs.append({"set": s, "round": b["round"], "cid": b["cid"], "checks": ch,
                         "model": b["meta"]["모델"], "resp": b["response"]})
    if skipped and runs:
        print(f"[{part}] 아직 덜 채워진 세트 {skipped} 는 제외하고 분석합니다.")
    # 한 파트에 모델이 섞였으면 가장 많은 모델만 남긴다: 다른 모델 응답이 들어 있는 (세트, 라운드)는 짝 전체를 제외
    if runs:
        main_model = max({r["model"] for r in runs}, key=lambda m: sum(r["model"] == m for r in runs))
        bad = {(r["set"], r["round"]) for r in runs if r["model"] != main_model}
        if bad:
            print(f"[{part}] 주 모델 {main_model} 외의 응답이 있는 짝 {sorted(bad)} 는 제외합니다.")
            runs = [r for r in runs if (r["set"], r["round"]) not in bad]
    return runs or None


def part_analysis(part):
    runs = load(part)
    if not runs:
        print(f"[{part}] 아직 모든 응답이 채워지지 않아 건너뜁니다.")
        return
    cells = {(r["set"], r["round"], r["cid"]): r["checks"] for r in runs}
    keys = sorted({(s, rd) for s, rd, _ in cells})
    cids = sorted({r["cid"] for r in runs})
    rng = random.Random(SEED)
    rows = []
    for c in cids:
        row = {"cid": c, "name": NAMES[c], "rate": st.mean(rate(cells[(s, rd, c)]) for s, rd in keys)}
        if c != "C00":
            d = [rate(cells[(s, rd, c)]) - rate(cells[(s, rd, "C00")]) for s, rd in keys]
            m = st.mean(d)
            bs = sorted(st.mean(rng.choices(d, k=len(d))) for _ in range(NB))
            row.update(diff=m, lo=bs[int(NB * .025)], hi=bs[int(NB * .975)],
                       p=sum(abs(st.mean([x * rng.choice((1, -1)) for x in d])) >= abs(m) - 1e-9
                             for _ in range(NP)) / NP)
        rows.append(row)
    # 예시 1개(C04)와의 직접 비교 (V 에서만): 짝지은 차이, 부트스트랩 구간, 순열검정
    direct = []
    if "C04" in cids and ("V2" in cids or "L1" in cids or "E1" in cids):
        for c in ("V2", "V3", "L1", "L2", "E1", "E2"):
            if c not in cids:
                continue
            d = [rate(cells[(s, rd, c)]) - rate(cells[(s, rd, "C04")]) for s, rd in keys]
            m = st.mean(d)
            bs = sorted(st.mean(rng.choices(d, k=len(d))) for _ in range(NB))
            pv = sum(abs(st.mean([x * rng.choice((1, -1)) for x in d])) >= abs(m) - 1e-9
                     for _ in range(NP)) / NP
            direct.append((c, m, bs[int(NB * .025)], bs[int(NB * .975)], pv))
    if part == "L" and direct:  # 길이 통제 판정(사전 기준): L-C04 구간 상한<0이고 -10%p 이하이면 "예시가 더 높음", L-C00 > 10%p이고 구간 하한>0이면 "통제 글도 효과"
        with open(OUT / "L_verdict.csv", "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["통제 조건", "통제-기본(%p)", "하한", "상한", "통제-예시(%p)", "하한", "상한", "판정"])
            for c, m, lo, hi, pv in direct:
                r = next(x for x in rows if x["cid"] == c)
                if hi < 0 and m <= -TH:
                    v = "예시가 더 높음(길이·내용만으로 설명되지 않음)"
                elif r["diff"] > TH and r["lo"] > 0:
                    v = "통제 글도 효과가 있음"
                else:
                    v = "혼합"
                w.writerow([c, f"{r['diff']:+.1f}", f"{r['lo']:+.1f}", f"{r['hi']:+.1f}", f"{m:+.1f}", f"{lo:+.1f}", f"{hi:+.1f}", v])
                print(f"   [L 판정] {c}: {v}")
    if part in ("E", "E_gpt6") and direct:  # 다른 예시 판정(사전 기준): 기본 대비 +10%p 초과이고 구간 하한>0이면 "효과 유지", 그 밖은 "효과 불분명"
        with open(OUT / f"{part}_verdict.csv", "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["조건", "기본 대비(%p)", "하한", "상한", "도서관 예시 대비(%p)", "하한", "상한", "판정"])
            for c, m, lo, hi, pv in direct:
                r = next(x for x in rows if x["cid"] == c)
                v = "효과 유지" if (r["diff"] > TH and r["lo"] > 0) else "효과 불분명"
                w.writerow([c, f"{r['diff']:+.1f}", f"{r['lo']:+.1f}", f"{r['hi']:+.1f}", f"{m:+.1f}", f"{lo:+.1f}", f"{hi:+.1f}", v])
                print(f"   [E 판정] {c}: {v}")
    tests = [r for r in rows if r["cid"] != "C00"]
    order = sorted(range(len(tests)), key=lambda i: tests[i]["p"])
    prev = 0.0
    for k, i in enumerate(order):
        prev = max(prev, min(1.0, tests[i]["p"] * (len(tests) - k)))
        tests[i]["holm"] = prev
    models = sorted({r["model"] for r in runs})
    with open(OUT / f"{part}_summary.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["조건", "조건명", "모델", "짝 수", "준수율(%)", "기본 대비(%p)", "95%구간 하한", "95%구간 상한",
                    "순열 p", "Holm p", "10%p 기준"])
        for r in rows:
            if r["cid"] == "C00":
                w.writerow([r["cid"], r["name"], "/".join(models), len(keys), f"{r['rate']:.1f}"] + [""] * 6)
            else:
                w.writerow([r["cid"], r["name"], "/".join(models), len(keys), f"{r['rate']:.1f}",
                            f"{r['diff']:+.1f}", f"{r['lo']:+.1f}", f"{r['hi']:+.1f}", f"{r['p']:.4f}",
                            f"{r['holm']:.4f}", "구분됨" if abs(r["diff"]) > TH else "기본과 구분되지 않음"])
    if direct:
        with open(OUT / f"{part}_vs_C04.csv", "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["조건", "예시 1개(C04) 대비(%p)", "95%구간 하한", "95%구간 상한", "순열 p(보정 전)"])
            for c, m, lo, hi, pv in direct:
                w.writerow([c, f"{m:+.1f}", f"{lo:+.1f}", f"{hi:+.1f}", f"{pv:.4f}"])
                print(f"   {c} vs C04: {m:+.1f}%p [{lo:+.1f},{hi:+.1f}] p={pv:.4f}")
    with open(OUT / f"{part}_per_rule.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        names = RULES_D if part == "D_gpt6" else RULES
        w.writerow(["조건", "조건명"] + names)
        for c in cids:
            rs = [r for r in runs if r["cid"] == c]
            w.writerow([c, NAMES[c]] + [f"{sum(r['checks'][i] for r in rs)}/{len(rs)}" for i in range(len(names))])
    print(f"[{part}] 모델 {models} / 짝 {len(keys)}")
    for r in rows:
        print("  ", r["cid"], r["name"], f"{r['rate']:.1f}",
              "" if r["cid"] == "C00" else f"{r['diff']:+.1f}%p [{r['lo']:+.1f},{r['hi']:+.1f}] Holm p={r['holm']:.4f}")


def shingles(t, k=6):
    t = re.sub(r"\s+", "", t)
    return {t[i:i + k] for i in range(len(t) - k + 1)}


def quality():
    jf = ROOT / "data" / "Q" / "judgments.jsonl"
    js = [json.loads(l) for l in jf.read_text(encoding="utf-8").splitlines()] if jf.exists() else []
    if len(js) >= 60:
        by = {}
        for j in js:
            win = None
            if j["pick"] in "AB" and j["pick"]:
                win = (j["a_is"] == "C04") == (j["pick"] == "A")  # C04가 이겼는가
            by.setdefault((j["set"], j["round"]), []).append(win)
        share = [sum(1 for x in v if x) / len(v) for v in by.values() if all(x is not None for x in v)]
        rng = random.Random(SEED)
        bs = sorted(st.mean(rng.choices(share, k=len(share))) for _ in range(NB))
        a_pick = sum(j["pick"] == "A" for j in js)
        print(f"[Q] 예시(C04) 승률 {st.mean(share)*100:.1f}%  95%구간 [{bs[int(NB*.025)]*100:.1f}, {bs[int(NB*.975)]*100:.1f}]"
              f"  (짝 {len(share)}, 판정 {len(js)}, A 선택 {a_pick}/{len(js)})")
        with open(OUT / "Q_judge.csv", "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["C04 승률(%)", "95%구간 하한", "95%구간 상한", "짝 수", "판정 수", "A 선택 수"])
            w.writerow([f"{st.mean(share)*100:.1f}", f"{bs[int(NB*.025)]*100:.1f}", f"{bs[int(NB*.975)]*100:.1f}",
                        len(share), len(js), a_pick])
    else:
        print(f"[Q] 심판 판정 {len(js)}/60 — 아직 건너뜁니다.")
    # 베끼기: 예시 글과 겹치는 6글자 조각의 비율 (본 실험 응답, 비용 없음)
    ex = shingles(CFG["tasks"][0]["example"])
    vals = {"C00": [], "C04": []}
    for s in (1, 2, 3):
        for b in score.parse((MAIN.parent / "data" / f"set{s}" / "run_sheet.txt").read_text(encoding="utf-8")):
            if b["cid"] in vals:
                sh = shingles(b["response"])
                vals[b["cid"]].append(len(sh & ex) / len(sh) * 100 if sh else 0)
    print(f"[Q] 예시와 겹치는 6글자 조각(%)  기본 {st.mean(vals['C00']):.2f} / 예시 제시 {st.mean(vals['C04']):.2f}")
    with open(OUT / "Q_overlap.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["조건", "겹침 평균(%)", "응답 수"])
        for c, v in vals.items():
            w.writerow([c, f"{st.mean(v):.2f}", len(v)])


if __name__ == "__main__":
    for p in ("V", "R", "ALL", "R_gpt6", "M_m1", "M_m2", "M_gpt", "M_gpt6", "X", "X_gpt6", "S", "S_gpt6", "L", "D_gpt6", "E", "E_gpt6"):
        part_analysis(p)
    quality()
