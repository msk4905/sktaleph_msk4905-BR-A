"""진행률 확인 (실행 명령 한 줄마다 따로 보여 준다).
  python ext/code/progress.py            한 번 보여 주고 끝낸다
  python ext/code/progress.py --watch    5초마다 화면을 새로 고쳐 실시간으로 보여 준다 (끝내려면 Ctrl+C)
  python ext/code/progress.py --watch 2  2초마다
읽기만 하며 아무것도 바꾸지 않는다.
"""
import datetime
import os
import pathlib
import sys
import time
import unicodedata

PH = "(여기에 응답 붙여넣기)"
ROOT = pathlib.Path(__file__).resolve().parent.parent
# (파트, 표시 이름, 이 파트를 돌리는 명령의 --limit)
PARTS = [("R_gpt6", "주 실험 GPT 6    ", 1000), ("X", "어긋난 예시 Gem. ", 500), ("X_gpt6", "어긋난 예시 GPT6", 500),
         ("M_gpt6", "GPT 6 Luna      ", 400), ("M_gpt", "GPT 5.6 Luna    ", 400),
         ("R", "주 실험 반복     ", 700), ("V", "예시 변형       ", 240),
         ("M_m2", "Gemini 3.1 Lite ", 100),
         ("S_gpt6", "새 과제 GPT 6    ", 320), ("S", "새 과제 Gemini   ", 160),
         ("L", "길이 통제 Gemini ", 400), ("D_gpt6", "어려운 지시 GPT6 ", 640), ("E", "다른 예시 Gemini ", 400), ("E_gpt6", "다른 예시 GPT6  ", 400)]
JUDGE = [("ALL", "사실 점검 ALL    ", 200), ("GPT6", "사실 점검 GPT6   ", 200)]
sys.stdout.reconfigure(encoding="utf-8")
RECENT = 20  # 속도는 가장 최근에 끝난 호출 20개의 시각으로 계산한다
IDLE_MIN = 10  # 마지막 호출이 이보다 오래됐으면 지금은 돌아가고 있지 않다고 본다


def stamps(part):
    """파트 안에서 응답이 채워진 호출들의 시각(분 단위)을 모은다."""
    out = []
    for d in sorted((ROOT / "data").glob(f"{part}_set*")):
        try:
            t = (d / "run_sheet.txt").read_text(encoding="utf-8")
        except OSError:
            continue
        for b in t.split("\n=== ")[1:]:
            if PH in b:
                continue
            for line in b.splitlines():
                if line.startswith("시각:") and line[3:].strip():
                    try:
                        out.append(datetime.datetime.strptime(line[3:].strip(), "%Y-%m-%d %H:%M"))
                    except ValueError:
                        pass
                    break
    return sorted(out)


def eta(part, left):
    """(속도 문자열, 예상 완료 문자열). 속도는 최근 호출들의 시각 간격으로 계산한다."""
    if left == 0:
        return "", ""
    ts = stamps(part)[-RECENT:]
    now = datetime.datetime.now()
    if len(ts) < 3:
        return "", "예상 불가(최근 기록 부족)"
    if (now - ts[-1]).total_seconds() / 60 > IDLE_MIN:
        return "", f"지금은 멈춰 있음(마지막 {ts[-1]:%m-%d %H:%M})"
    span = max((ts[-1] - ts[0]).total_seconds() / 60, 1.0)  # 시각이 분 단위라 최소 1분으로 본다
    rate = (len(ts) - 1) / span
    done = now + datetime.timedelta(minutes=left / rate)
    mins = left / rate
    when = f"{mins:.0f}분 후" if mins < 120 else f"{mins / 60:.1f}시간 후"
    return f"{rate:.1f}회/분", f"예상 완료 {done:%m-%d %H:%M} ({when})"


def width(t):
    """콘솔에서 차지하는 칸 수(한글·전각 문자는 2칸)."""
    return sum(2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in t)


def pad(t, w, right=False):
    sp = " " * max(0, w - width(t))
    return sp + t if right else t + sp


WIDTHS = (18, 22, 7, 11, 10, 9)  # 명령, 진행 막대, 퍼센트, 횟수, 상태, 속도 (마지막 칸은 예상 완료)


def render(rows):
    head = ("명령", "진행률", "%", "횟수", "상태", "속도", "예상 완료")
    out = []
    for r in [head] + rows:
        cells = [pad(c, w, right=i in (2, 3)) for i, (c, w) in enumerate(zip(r, WIDTHS))]
        out.append("  ".join(cells + [r[6]]).rstrip())
    return "\n".join(out)


def show():
    rows = []
    for part, label, limit in PARTS:
        n = f = 0
        for d in sorted((ROOT / "data").glob(f"{part}_set*")):
            try:
                t = (d / "run_sheet.txt").read_text(encoding="utf-8")
            except OSError:
                continue  # 저장 중이라 잠깐 못 읽으면 이번 칸은 건너뜀
            n += t.count("\n=== ")
            f += t.count("\n=== ") - t.count(PH)
        left = n - f
        done_now = max(0, limit - left)  # 처음 시작할 때 이 명령이 해야 할 호출 수(limit) 기준
        pct = done_now / limit * 100
        speed, when = eta(part, left)
        rows.append((label.strip(), "[" + "#" * int(pct // 5) + " " * (20 - int(pct // 5)) + "]", f"{pct:.1f}",
                     f"{done_now}/{limit}", "완료" if left == 0 else f"{left}회 남음", speed, when))
    for tgt, label, total in JUDGE:
        f = ROOT / "data" / "F" / f"{tgt}.jsonl"
        try:
            n = len(f.read_text(encoding="utf-8").splitlines()) if f.exists() else 0
        except OSError:
            continue
        pct = n / total * 100
        rows.append((label.strip(), "[" + "#" * int(pct // 5) + " " * (20 - int(pct // 5)) + "]", f"{pct:.1f}",
                     f"{n}/{total}", "완료" if n >= total else f"{total - n}회 남음", "", ""))
    return render(rows)


if "--watch" in sys.argv:
    i = sys.argv.index("--watch")
    sec = float(sys.argv[i + 1]) if i + 1 < len(sys.argv) else 5.0
    try:
        while True:
            out = show()
            os.system("cls" if os.name == "nt" else "clear")
            print(f"진행률 (갱신 {time.strftime('%H:%M:%S')}, {sec:g}초마다 / 종료 Ctrl+C)\n")
            print(out)
            time.sleep(sec)
    except KeyboardInterrupt:
        pass
else:
    print(show())
