"""사실 점검(F) 분석.  python ext/code/analyze_facts.py   (키 불필요)

같은 (세트,라운드)의 기본(C00)과 예시 1개(C04)를 짝지어 지표별 차이(C04-C00)와 부트스트랩 95% 구간(20,000회, 시드 10), 부호 뒤집기 순열검정 p를 낸다.
지표: 사실 보존율(%), 지어낸 사실 수, 어조(1~5), 자연스러움(1~5).
판정(결과를 보기 전에 정함): 사실 보존율 차이의 구간 상한이 0 미만이면 "예시가 사실 보존을 낮춤", 하한이 0 초과이면 "높임", 그 밖에는 "차이 증거 없음".
"""
import csv
import json
import pathlib
import random
import statistics as st

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)
NB = NP = 20000
METRICS = [("사실 보존율(%)", lambda j: sum(j["facts"]) / len(j["facts"]) * 100),
           ("지어낸 사실 수", lambda j: len(j["added"])),
           ("어조(1~5)", lambda j: j["tone"]),
           ("자연스러움(1~5)", lambda j: j["natural"])]
LABEL = {"ALL": "gemini-3.5-flash-lite 응답(10세트)", "GPT6": "gpt-6-luna 응답(10세트)"}


def main():
    rows = []
    for t in ("ALL", "GPT6"):
        f = ROOT / "data" / "F" / f"{t}.jsonl"
        if not f.exists():
            print(f"[F {t}] 판정 파일이 없어 건너뜁니다.")
            continue
        recs = [json.loads(l) for l in f.read_text(encoding="utf-8").splitlines()]
        err = sum(1 for r in recs if r.get("error"))
        good = {(r["set"], r["round"], r["cid"]): r for r in recs if not r.get("error")}
        keys = sorted({(s, rd) for s, rd, _ in good if (s, rd, "C00") in good and (s, rd, "C04") in good})
        if not keys:
            print(f"[F {t}] 짝이 아직 없습니다(판정 {len(recs)}건, 구문 오류 {err}건).")
            continue
        judge = "/".join(sorted({r["judge"] for r in recs}))
        print(f"[F {t}] 심판 {judge} / 짝 {len(keys)} / 판정 {len(recs)}건 중 구문 오류 {err}건")
        rng = random.Random(10)
        for name, fn in METRICS:
            a = [fn(good[(s, r, "C00")]) for s, r in keys]
            b = [fn(good[(s, r, "C04")]) for s, r in keys]
            d = [y - x for x, y in zip(a, b)]
            m = st.mean(d)
            bs = sorted(st.mean(rng.choices(d, k=len(d))) for _ in range(NB))
            lo, hi = bs[int(NB * .025)], bs[int(NB * .975)]
            p = sum(abs(st.mean([x * rng.choice((1, -1)) for x in d])) >= abs(m) - 1e-9 for _ in range(NP)) / NP
            rows.append([t, LABEL[t], judge, len(keys), name, f"{st.mean(a):.2f}", f"{st.mean(b):.2f}",
                         f"{m:+.2f}", f"{lo:+.2f}", f"{hi:+.2f}", f"{p:.4f}"])
            v = ""
            if name.startswith("사실"):
                v = "  -> 예시가 사실 보존을 낮춤" if hi < 0 else ("  -> 높임" if lo > 0 else "  -> 차이 증거 없음")
            print(f"   {name}: 기본 {st.mean(a):.2f} / 예시 {st.mean(b):.2f} / 차이 {m:+.2f} [{lo:+.2f},{hi:+.2f}] p={p:.4f}{v}")
    if rows:
        with open(OUT / "F_summary.csv", "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.writer(fh)
            w.writerow(["대상", "설명", "심판 모델", "짝 수", "지표", "기본 평균", "예시 1개 평균", "차이", "95% 하한", "95% 상한", "순열 p"])
            w.writerows(rows)


if __name__ == "__main__":
    main()
