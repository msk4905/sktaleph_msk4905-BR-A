"""내용 질 비교: 본 실험의 기본(C00)과 예시 제시(C04) 응답을 같은 과제끼리 짝지어 AI 심판에게 보여 준다.
짝마다 A/B 위치를 바꿔 2번 묻는다(30짝 x 2 = 60회). 결과는 data/Q/judgments.jsonl 에 쌓이며 이어서 실행된다.

  python code/judge_quality.py --model 심판모델ID --limit 60
"""
import argparse
import json
import os
import pathlib
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent.parent
MAIN = ROOT.parent / "code"
sys.path.insert(0, str(MAIN))
import run_gemini  # noqa: E402
import score  # noqa: E402

OUT = ROOT / "data" / "Q" / "judgments.jsonl"
Q = ("글자 수·문단 수·문장 수 같은 형식 규칙은 평가하지 말고, 요청에 담긴 내용(사실)을 빠짐없이 정확하게 전하고 "
     "읽기에 자연스러운 글이 어느 쪽인지만 골라 줘. 답은 A 또는 B 한 글자만 써.")


def pairs():
    cfg = json.loads((MAIN / "conditions.json").read_text(encoding="utf-8"))
    tasks = {t["id"]: t for t in cfg["tasks"]}
    got = {}
    for s in (1, 2, 3):
        for b in score.parse((MAIN.parent / "data" / f"set{s}" / "run_sheet.txt").read_text(encoding="utf-8")):
            if b["cid"] in ("C00", "C04"):
                got[(s, b["round"], b["cid"])] = (b["tid"], b["response"])
    for (s, r, c), (tid, resp) in sorted(got.items()):
        if c == "C00":
            yield s, r, tid, tasks[tid]["intro"], resp, got[(s, r, "C04")][1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--limit", type=int, default=60)
    ap.add_argument("--pause", type=float, default=6.0)
    a = ap.parse_args()
    key = os.environ.get("GEMINI_API_KEY") or sys.exit("GEMINI_API_KEY 환경변수가 없습니다.")
    OUT.parent.mkdir(parents=True, exist_ok=True)
    done = set()
    if OUT.exists():
        for l in OUT.read_text(encoding="utf-8").splitlines():
            j = json.loads(l)
            done.add((j["set"], j["round"], j["a_is"]))
    n = 0
    for s, r, tid, intro, c00, c04 in pairs():
        for a_is in ("C00", "C04"):
            if (s, r, a_is) in done:
                continue
            if n >= a.limit:
                print(f"이번 실행에서 {n}건 저장")
                return
            A, B = (c00, c04) if a_is == "C00" else (c04, c00)
            p = f"같은 요청에 대해 쓴 두 글이야.\n\n요청: {intro}\n\n[글 A]\n{A}\n\n[글 B]\n{B}\n\n{Q}"
            text, info = run_gemini.generate(a.model, p, key)
            if not text:
                print("실패:", info, "- 중단합니다. 다시 실행하면 이어서 합니다.")
                print(f"이번 실행에서 {n}건 저장")
                return
            pick = next((ch for ch in text if ch in "AB"), "")
            with OUT.open("a", encoding="utf-8") as f:
                f.write(json.dumps({"set": s, "round": r, "tid": tid, "a_is": a_is, "pick": pick,
                                    "raw": text[:40], "model": a.model}, ensure_ascii=False) + "\n")
            n += 1
            print(f"[{n}] 세트{s} 라운드{r} A={a_is} -> {pick}", flush=True)
            time.sleep(a.pause)
    print(f"이번 실행에서 {n}건 저장")


if __name__ == "__main__":
    main()
