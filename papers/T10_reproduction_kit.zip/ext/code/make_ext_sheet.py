"""보강 실험용 run_sheet 생성.

  python code/make_ext_sheet.py --part R --set 4 --seed 23 --out data/R_set4
  python code/make_ext_sheet.py --part V --set 1 --seed 40 --out data/V_set1
  python code/make_ext_sheet.py --part M --set 1 --seed 30 --out data/M_m1_set1

V : 예시 변형 비교 (C00 기본, C04 예시 1개, V2 예시 2개, V3 형식 틀)
M : 다른 모델 반복 (C00 기본, C04 예시 1개)
X : 어긋나는 예시(기본, 예시 1개, 정상 예시 중립 안내, 구조 어긋남, 문체 어긋남)
R : 주 실험 반복(10개 조건 전부, 세트 4~10)
E / E_gpt6 : 다른 예시(C00 기본, C04 도서관 예시, E1 헌 옷 수거 12문장, E2 분리배출 10문장). 한 세트 = 과제 10개 x 4조건 = 40회
L : 길이 통제(C00 기본, C04 예시, L1 같은 길이 줄글, L2 같은 길이 무관한 글). 한 세트 = 과제 10개 x 4조건 = 40회
D_gpt6 : 어려운 지시(지시 12개) 과제 8개(T21~T28, tasks_D.json) x 주 실험 10개 조건. 한 세트 = 80회
S : 다른 글 종류 과제 8개(T11~T18, tasks_S.json), C00 기본 / C04 예시 1개. 한 세트 = 과제 8개 x 2조건 = 16회
M_gpt : OpenAI API(gpt-5.6-luna) 확인(C00 기본, C04 예시 1개)
한 세트 = 과제 10개를 한 번씩, 라운드마다 모든 조건이 같은 과제를 쓰고 조건 순서만 섞는다.
"""
import argparse
import json
import pathlib
import random
import sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
MAIN = ROOT.parent / "code"
sys.path.insert(0, str(MAIN))
import make_run_sheet as base  # noqa: E402

PLACEHOLDER = base.PLACEHOLDER
HEADER_EX = "예시(내용은 다르지만 위 지시를 모두 지킨 글이야):"
HEADER_EX2 = "예시 두 개(내용은 다르지만 둘 다 위 지시를 모두 지킨 글이야):"
HEADER_SK = "형식 틀(괄호 안을 내용으로 채워 줘):"

HEADER_NEUTRAL = "예시(내용은 다른 글이야):"
EX_STRUCT = (
    "▶ 도서관 이용 안내\n"
    "이번 달부터 도서관이 달라져요. 열람실 운영 시간이 조금 바뀌어요.\n\n"
    "▶ 운영 시간\n"
    "평일에는 오전 9시에 문을 열어요. 저녁 8시까지 열람실을 이용할 수 있어요.\n\n"
    "▶ 대출 방법\n"
    "책은 한 번에 다섯 권까지 빌릴 수 있어요. 대출 기간은 2주예요!\n\n"
    "▶ 연장과 반납\n"
    "기간이 끝나기 전에 연장도 가능해요. 반납함은 입구 옆에 있어요.\n\n"
    "▶ 문의\n"
    "궁금한 점은 안내 데스크에 편하게 물어보세요. 전화로도 문의할 수 있어요."
)
EX_STYLE = (
    "▶ 도서관 이용 안내\n"
    "이번 달부터 도서관이 달라집니다. 열람실 운영 시간이 조금 바뀝니다.\n\n"
    "▶ 운영 시간\n"
    "평일에는 오전 9시에 문을 엽니다. 저녁 8시까지 열람실을 이용할 수 있습니다. 주말에는 오후 6시에 문을 닫습니다.\n\n"
    "▶ 대출 방법\n"
    "책은 한 번에 다섯 권까지 빌릴 수 있습니다. 대출 기간은 2주입니다! 기간이 끝나기 전에 연장도 가능합니다.\n\n"
    "▶ 문의\n"
    "궁금한 점은 안내 데스크에 편하게 물어보십시오. 전화로도 문의할 수 있습니다."
)
HEADER_CTRL = "참고 글:"
# 길이 통제 글: 예시(C04의 도서관 이용 안내, 238자)와 비슷한 길이(공백 포함)의 줄글. 소제목·문단 구분이 없다.
CTRL_PROSE = "이번 달부터 우리 동네 도서관이 여러모로 달라져요. 열람실 운영 시간이 조금 바뀌어요. 평일에는 아침 일찍 오전 9시에 문을 열어요. 저녁 8시까지 열람실을 편하게 이용할 수 있어요. 주말에는 오후 6시에 문을 닫아요. 책은 한 번에 다섯 권까지 집으로 빌려 갈 수 있어요. 대출 기간은 2주예요! 기간이 끝나기 전에 연장도 가능해요. 궁금한 점은 안내 데스크에 편하게 물어보세요. 전화로도 언제든 문의할 수 있어요."  # 예시와 같은 내용·문체, 형식만 없음
CTRL_OTHER = "한국에는 봄, 여름, 가을, 겨울의 네 계절이 있습니다. 봄에는 기온이 올라 꽃이 피기 시작합니다. 여름에는 비가 많이 내리고 덥습니다. 가을에는 하늘이 맑고 단풍이 곱게 물듭니다. 겨울에는 기온이 내려가 눈이 오기도 합니다. 계절마다 입는 옷이 달라집니다. 먹는 음식도 철에 따라 바뀝니다. 농사를 짓는 시기도 계절을 따라 정해집니다. 사람들은 계절에 맞춰 생활 방식을 바꿉니다. 이렇게 사계절은 우리 삶에 큰 영향을 줍니다."  # 무관한 주제, 합니다체
EXAMPLE2 = (
    "▶ 동네 수영장 안내\n"
    "다음 주부터 수영장이 새로 열려요. 이용 방법을 간단히 알려 드려요.\n\n"
    "▶ 이용 시간\n"
    "아침 7시부터 밤 9시까지 문을 열어요. 월요일은 청소하는 날이라 쉬어요. 점심시간에는 어린이 시간이 따로 있어요.\n\n"
    "▶ 이용 요금\n"
    "성인은 한 번에 오천 원이에요. 어린이는 삼천 원이에요! 월 회원으로 가입하면 훨씬 저렴해져요.\n\n"
    "▶ 준비물\n"
    "수영복과 수영모는 꼭 챙겨 오셔야 해요. 물안경과 수건은 매점에서도 살 수 있어요."
)
EXAMPLE_E1 = (
    '▶ 헌 옷 수거 안내\n'
    '다음 달부터 헌 옷 수거가 시작돼요. 수거 방법을 먼저 알려 드려요.\n'
    '\n'
    '▶ 수거 일정\n'
    '수거는 매주 수요일 아침에 해요. 전날 밤까지 문 앞에 내놓으면 돼요. 비가 오는 날에는 다음 날로 미뤄져요.\n'
    '\n'
    '▶ 내놓는 방법\n'
    '깨끗하게 빤 옷만 봉투에 담아 주세요. 신발과 이불은 따로 묶어 주세요. 봉투 입구는 끈으로 꼭 묶어 주세요. 무게는 열 킬로그램을 넘기지 않아야 해요!\n'
    '\n'
    '▶ 문의\n'
    '궁금한 점은 주민센터에 물어보세요. 전화로 문의해도 괜찮아요. 담당자가 친절하게 알려 드려요.'
)  # 다른 주제(헌 옷 수거), 12문장(2/3/4/3)
EXAMPLE_E2 = (
    '▶ 분리배출 안내\n'
    '이번 주부터 배출 방법이 바뀌어요. 달라진 점을 알려 드려요.\n'
    '\n'
    '▶ 종이와 플라스틱\n'
    '종이는 접어서 묶어 내놓아요. 플라스틱은 깨끗이 헹궈서 버려요. 라벨은 가능하면 떼어 주세요.\n'
    '\n'
    '▶ 음식물 쓰레기\n'
    '물기를 꼭 짜서 전용 봉투에 담아요. 뼈나 조개껍데기는 일반 쓰레기예요! 봉투는 집 앞에 놓아 주세요.\n'
    '\n'
    '▶ 문의\n'
    '헷갈리면 구청 홈페이지를 확인해 보세요. 전화로도 문의할 수 있어요.'
)  # 다른 주제(분리배출), 10문장(2/3/3/2: C04와 같은 문장 구성)
SKELETON = (
    "▶ (소제목)\n(문장). (문장).\n\n"
    "▶ (소제목)\n(문장). (문장). (문장).\n\n"
    "▶ (소제목)\n(문장). (문장)! (문장).\n\n"
    "▶ (소제목)\n(문장). (문장)."
)

X_CONDS = [("C00", "기본", "base"), ("C04", "예시 1개", "example"),
           ("N0", "정상 예시(중립 안내)", "ex_neutral"), ("X1", "구조 어긋난 예시", "ex_struct"),
           ("X2", "문체 어긋난 예시", "ex_style")]
PARTS = {
    "X": X_CONDS,
    "X_gpt6": X_CONDS,
    "R": [],
    "D_gpt6": [],  # 어려운 지시(12개) 과제 T21~T28 + 주 실험과 같은 10개 조건
    "R_gpt6": [],  # 주 실험과 같은 10개 조건(conditions.json)을 그대로 쓴다

    "V": [("C00", "기본", "base"), ("C04", "예시 1개", "example"),
          ("V2", "예시 2개", "example2"), ("V3", "형식 틀", "skeleton")],
    "M": [("C00", "기본", "base"), ("C04", "예시 1개", "example")],
    "M_gpt": [("C00", "기본", "base"), ("C04", "예시 1개", "example")],
    "L": [("C00", "기본", "base"), ("C04", "예시 1개", "example"),
          ("L1", "같은 길이 줄글(예시와 같은 내용)", "ctrl_prose"), ("L2", "같은 길이 무관한 글", "ctrl_other")],
    "E": [("C00", "기본", "base"), ("C04", "예시 1개", "example"),
          ("E1", "다른 예시 A(12문장)", "ex_e1"), ("E2", "다른 예시 B(10문장)", "ex_e2")],
    "E_gpt6": [("C00", "기본", "base"), ("C04", "예시 1개", "example"),
               ("E1", "다른 예시 A(12문장)", "ex_e1"), ("E2", "다른 예시 B(10문장)", "ex_e2")],
    "S": [("C00", "기본", "base"), ("C04", "예시 1개", "example")],  # 다른 글 종류 과제 T11~T18
    "S_gpt6": [("C00", "기본", "base"), ("C04", "예시 1개", "example")],
}


def prompt(task, kind):
    b = task["intro"] + " " + base.chain(task)
    if kind == "base":
        return b
    if kind == "example":
        return b + "\n" + HEADER_EX + "\n" + task["example"]
    if kind == "example2":
        return b + "\n" + HEADER_EX2 + "\n" + task["example"] + "\n\n" + EXAMPLE2
    if kind == "skeleton":
        return b + "\n" + HEADER_SK + "\n" + SKELETON
    if kind == "ctrl_prose":
        return b + "\n" + HEADER_CTRL + "\n" + CTRL_PROSE
    if kind == "ctrl_other":
        return b + "\n" + HEADER_CTRL + "\n" + CTRL_OTHER
    if kind == "ex_e1":
        return b + "\n" + HEADER_EX + "\n" + EXAMPLE_E1
    if kind == "ex_e2":
        return b + "\n" + HEADER_EX + "\n" + EXAMPLE_E2
    if kind == "ex_neutral":
        return b + "\n" + HEADER_NEUTRAL + "\n" + task["example"]
    if kind == "ex_struct":
        return b + "\n" + HEADER_NEUTRAL + "\n" + EX_STRUCT
    if kind == "ex_style":
        return b + "\n" + HEADER_NEUTRAL + "\n" + EX_STYLE
    raise ValueError(kind)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--part", required=True, choices=PARTS)
    ap.add_argument("--set", type=int, required=True)
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    out = pathlib.Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    f = out / "run_sheet.txt"
    if f.exists():
        sys.exit("run_sheet.txt 가 이미 있어 덮어쓰지 않습니다.")
    cfg = json.loads((MAIN / "conditions.json").read_text(encoding="utf-8"))
    tasks = cfg["tasks"]
    if a.part in ("S", "S_gpt6"):
        tasks = json.loads((HERE / "tasks_S.json").read_text(encoding="utf-8"))["tasks"]
    if a.part == "D_gpt6":
        tasks = json.loads((HERE / "tasks_D.json").read_text(encoding="utf-8"))["tasks"]
    conds = ([(c["id"], c["name"], c) for c in cfg["conditions"]] if a.part in ("R", "R_gpt6", "D_gpt6") else PARTS[a.part])
    rng = random.Random(a.seed)
    lines = [f"# 보강 실험 {a.part} / 세트 {a.set}", f"# 난수 시드: {a.seed}",
             f"# 라운드 수: {len(tasks)} / 조건 수: {len(conds)}", ""]
    n = 0
    for r, task in enumerate(tasks, 1):
        order = conds[:]
        rng.shuffle(order)
        for cid, name, kind in order:
            n += 1
            lines += [f"=== {n:03d} | 라운드 {r} | {task['id']} | {cid} | {name} ===",
                      "모델: ", "전환안내: 아니오", "시각: ", "--- 프롬프트 ---",
                      (base.build_prompt(task, kind, cfg) if a.part in ("R", "R_gpt6", "D_gpt6") else prompt(task, kind)), "--- 응답 ---", PLACEHOLDER, ""]
    f.write_text("\n".join(lines), encoding="utf-8")
    print(f"{f} 생성: 총 {n}회")


if __name__ == "__main__":
    main()
