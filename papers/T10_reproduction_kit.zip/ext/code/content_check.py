"""내용 보존 점검(호출 없음). 본 실험 응답에서 과제 문장에 있던 사실(숫자+단위, 따옴표 이름)이
응답에 그대로 들어 있는 비율과 응답 길이를, 기본(C00)과 예시 제시(C04)로 비교한다.
  python ext/code/content_check.py   (결과: ext/results/content_check.csv)
사후(事後) 분석이다: 심판 결과를 본 뒤에 추가했다.
"""
import csv
import json
import pathlib
import random
import re
import statistics as st
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
MAIN = ROOT.parent / "code"
sys.path.insert(0, str(MAIN))
import score  # noqa: E402

CFG = json.loads((MAIN / "conditions.json").read_text(encoding="utf-8"))
TASKS = {t["id"]: t for t in CFG["tasks"]}
UNIT = "월일년개시분원%회주명자g"


def norm(t):
    return re.sub(r"[\s,]", "", t)


def facts(intro):
    nums = re.findall(rf"\d[\d,:\-]*[{UNIT}]?", intro)
    quoted = re.findall(r"[‘'『「]([^’'』」]{2,20})[’'』」]", intro)
    out = []
    for f in nums + quoted:
        f = norm(f).rstrip("-")
        if f and f not in out:
            out.append(f)
    return out


def main():
    rows = []
    for s in (1, 2, 3):
        text = (MAIN.parent / "data" / f"set{s}" / "run_sheet.txt").read_text(encoding="utf-8")
        for b in score.parse(text):
            if b["cid"] not in ("C00", "C04"):
                continue
            fs = facts(TASKS[b["tid"]]["intro"])
            r = norm(b["response"])
            cov = sum(f in r for f in fs) / len(fs) * 100
            rows.append((s, b["round"], b["cid"], cov, len(re.sub(r"\s+", "", b["response"]))))
    by = {}
    for s, rd, c, cov, ln in rows:
        by.setdefault((s, rd), {})[c] = (cov, ln)
    d_cov = [v["C04"][0] - v["C00"][0] for v in by.values()]
    d_len = [v["C04"][1] - v["C00"][1] for v in by.values()]
    rng = random.Random(10)

    def ci(d):
        bs = sorted(st.mean(rng.choices(d, k=len(d))) for _ in range(20000))
        return st.mean(d), bs[500], bs[19500]

    out = ROOT / "results" / "content_check.csv"
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["지표", "기본(C00) 평균", "예시(C04) 평균", "차이(C04-C00)", "95%구간 하한", "95%구간 상한", "짝 수"])
        for name, k, d in (("사실 보존율(%)", 0, d_cov), ("응답 길이(공백 제외 글자)", 1, d_len)):
            a = st.mean(v["C00"][k] for v in by.values())
            b = st.mean(v["C04"][k] for v in by.values())
            m, lo, hi = ci(d)
            w.writerow([name, f"{a:.1f}", f"{b:.1f}", f"{m:+.1f}", f"{lo:+.1f}", f"{hi:+.1f}", len(d)])
            print(f"{name}: 기본 {a:.1f} / 예시 {b:.1f} / 차이 {m:+.1f} [{lo:+.1f}, {hi:+.1f}] (짝 {len(d)})")
    print("과제별 사실 수:", {t: len(facts(TASKS[t]['intro'])) for t in TASKS})


if __name__ == "__main__":
    main()
