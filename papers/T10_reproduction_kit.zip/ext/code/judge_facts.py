"""사실 점검(F): 응답마다 요청에 있던 사실이 들어 있는지, 지어낸 사실이 있는지, 어조와 자연스러움을 다른 회사 모델이 판정한다.

  python ext/code/judge_facts.py --target ALL  --api openai --model gpt-6-luna --limit 200
  python ext/code/judge_facts.py --target GPT6 --api gemini --model gemini-3.5-flash-lite --limit 200
  python ext/code/judge_facts.py --target ALL --show        (프롬프트 한 개만 출력, 호출 안 함)

대상 ALL : gemini-3.5-flash-lite 응답(주 실험 세트 1~3 + 반복 R 세트 4~10)의 기본(C00)과 예시 1개(C04), 200건 (심판은 OpenAI 모델)
대상 GPT6: gpt-6-luna 응답(M_gpt6 세트 1~10)의 C00, C04, 200건 (심판은 Gemini 모델)
응답이 어느 조건인지는 심판에게 알리지 않는다. 결과는 ext/data/F/{target}.jsonl 에 쌓이며 이어서 실행된다(이미 한 건은 다시 부르지 않는다).
구문 분석에 실패한 건은 기록만 하고 다시 부르지 않는다. 다시 부르려면 --retry-errors.
"""
import argparse
import json
import os
import pathlib
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent.parent
MAIN = ROOT.parent / "code"
sys.path.insert(0, str(MAIN))
import score  # noqa: E402

FACTS = json.loads((ROOT / "code" / "facts.json").read_text(encoding="utf-8"))
CFG = json.loads((MAIN / "conditions.json").read_text(encoding="utf-8"))
TASKS = {t["id"]: t for t in CFG["tasks"]}
OUT = ROOT / "data" / "F"


def items(target):
    if target == "ALL":
        dirs = [MAIN.parent / "data" / f"set{i}" for i in (1, 2, 3)] + [ROOT / "data" / f"R_set{i}" for i in range(4, 11)]
    else:
        dirs = [ROOT / "data" / f"M_gpt6_set{i}" for i in range(1, 11)]
    for d in dirs:
        s = int(d.name.rsplit("set", 1)[1])
        for b in score.parse((d / "run_sheet.txt").read_text(encoding="utf-8")):
            if b["cid"] in ("C00", "C04") and b["response"] not in ("", score.PLACEHOLDER) \
                    and b["meta"]["전환안내"] not in ("예", "y", "Y", "yes"):
                yield s, b["round"], b["cid"], b["tid"], b["response"]


def build(tid, resp):
    facts = "\n".join(f"{i}. {f}" for i, f in enumerate(FACTS[tid], 1))
    return (f"아래는 어떤 요청과, 그 요청에 대해 AI가 쓴 글이야. 글이 요청의 내용을 얼마나 정확하게 담았는지 평가해 줘. "
            f"글자 수, 문단 수, 문장 수 같은 형식 규칙은 평가하지 마.\n\n[요청]\n{TASKS[tid]['intro']}\n\n"
            f"[요청에 들어 있던 사실 목록]\n{facts}\n\n[글]\n{resp}\n\n"
            f"다음 JSON 한 개만 출력해. 설명은 쓰지 마.\n"
            f'{{"facts": [사실 1부터 {len(FACTS[tid])}까지 순서대로, 글에 정확하게 들어 있으면 true, 빠졌거나 틀리면 false], '
            f'"added": [요청에 없는데 글이 새로 지어낸 구체적인 숫자·날짜·이름·연락처·약속의 목록, 없으면 빈 배열], '
            f'"tone": 1~5 정수(요청한 글의 종류에 맞는 어조인가), "natural": 1~5 정수(한국어가 자연스럽고 읽기 쉬운가)}}')


def parse_json(text, n):
    a, b = text.find("{"), text.rfind("}")
    if a < 0 or b < 0:
        return None
    try:
        j = json.loads(text[a:b + 1])
        if (isinstance(j["facts"], list) and len(j["facts"]) == n and all(isinstance(x, bool) for x in j["facts"])
                and isinstance(j["added"], list) and j["tone"] in (1, 2, 3, 4, 5) and j["natural"] in (1, 2, 3, 4, 5)):
            return j
    except (ValueError, KeyError, TypeError):
        pass
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", choices=["ALL", "GPT6"], required=True)
    ap.add_argument("--api", choices=["gemini", "openai"])
    ap.add_argument("--model")
    ap.add_argument("--limit", type=int, default=200)
    ap.add_argument("--pause", type=float, default=None)
    ap.add_argument("--show", action="store_true")
    ap.add_argument("--retry-errors", action="store_true")
    a = ap.parse_args()
    if a.show:
        s, r, c, tid, resp = next(items(a.target))
        print(build(tid, resp))
        return
    if not (a.api and a.model):
        sys.exit("--api 와 --model 이 필요합니다.")
    if a.api == "gemini":
        import run_gemini as R
        key = os.environ.get("GEMINI_API_KEY") or sys.exit("GEMINI_API_KEY 환경변수가 없습니다.")
        pause = 6.0 if a.pause is None else a.pause
    else:
        import run_openai as R
        key = (os.environ.get("OPENAI_API_KEY") or "").strip().strip('"').strip("'")
        if not (key.isascii() and key.isprintable() and " " not in key and key):
            sys.exit("OPENAI_API_KEY 값이 올바르지 않습니다. 실제 키(sk-...)만 설정하세요.")
        pause = 2.0 if a.pause is None else a.pause
    OUT.mkdir(parents=True, exist_ok=True)
    f = OUT / f"{a.target}.jsonl"
    done = {}
    if f.exists():
        for l in f.read_text(encoding="utf-8").splitlines():
            j = json.loads(l)
            done[(j["set"], j["round"], j["cid"])] = j
    n = 0
    for s, r, c, tid, resp in items(a.target):
        k = (s, r, c)
        if k in done and not (a.retry_errors and done[k].get("error")):
            continue
        if n >= a.limit:
            break
        text, info = R.generate(a.model, build(tid, resp), key)
        if not text:
            print("실패:", info, "- 중단합니다. 다시 실행하면 이어서 합니다.")
            break
        j = parse_json(text, len(FACTS[tid]))
        rec = {"target": a.target, "set": s, "round": r, "cid": c, "tid": tid, "judge": a.model}
        rec.update(j if j else {"error": True, "raw": text[:300]})
        with f.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        n += 1
        print(f"[{n}] {a.target} 세트{s} 라운드{r} {c} {tid} -> " + ("구문 오류" if not j else f"사실 {sum(j['facts'])}/{len(j['facts'])}, 지어낸 {len(j['added'])}, 어조 {j['tone']}, 자연스러움 {j['natural']}"), flush=True)
        time.sleep(pause)
    print(f"이번 실행에서 {n}건 저장")


if __name__ == "__main__":
    main()
