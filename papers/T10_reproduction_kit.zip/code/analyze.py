"""세 세트(set1~set3)의 run_sheet.txt 를 채점하고 최종 분석표와 그래프를 만듭니다.

실행:  python code/analyze.py          (저장소 최상위 폴더에서)
입력:  data/set1~3/run_sheet.txt, code/conditions.json
출력:  results/ 폴더 (results_all.csv, summary_final.csv, per_rule.csv, per_task.csv, fig1.png, fig2.png)
의존:  표준 라이브러리만 필요. 그래프(fig*.png)는 matplotlib 이 있을 때만 만듭니다.
"""
import csv
import json
import pathlib
import random
import statistics as st
import sys
from math import comb

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import score  # noqa: E402

SEED = 10
N_BOOT = 20000
N_PERM = 20000
THRESHOLD = 10.0
SETS = [1, 2, 3]
RULE_SHORT = ["소제목 4줄", "문단 4개", "첫 문단 2문장", "느낌표 1회",
              "문단당 2~4문장", "전체 10~14문장", "해요체", "첫 문장 20자 이내"]


def rate(v):
    return sum(v) / len(v) * 100


def fisher(a, n1, b, n2):
    n, k = n1 + n2, a + b
    pr = lambda x: comb(n1, x) * comb(n2, k - x) / comb(n, k)
    p0 = pr(a)
    return sum(pr(x) for x in range(max(0, k - n2), min(n1, k) + 1) if pr(x) <= p0 + 1e-12)


def main():
    cfg = json.loads((HERE / "conditions.json").read_text(encoding="utf-8"))
    names = {c["id"]: c["name"] for c in cfg["conditions"]}
    extras = {c["id"]: c.get("extra") for c in cfg["conditions"]}
    tasks = {t["id"]: t for t in cfg["tasks"]}
    nrules = len(cfg["tasks"][0]["rules"])
    out = ROOT / "results"
    out.mkdir(exist_ok=True)

    runs = []
    for s in SETS:
        text = (ROOT / "data" / f"set{s}" / "run_sheet.txt").read_text(encoding="utf-8")
        for b in score.parse(text):
            resp = b["response"]
            if resp in ("", score.PLACEHOLDER):
                sys.exit(f"set{s} 호출 {b['call']} 의 응답이 비어 있습니다.")
            if b["meta"]["전환안내"] in ("예", "y", "Y", "yes"):
                continue  # 제외 규칙
            task = tasks[b["tid"]]
            checks = [score.rule_pass(r, resp) for r in task["rules"]]
            ek = extras.get(b["cid"])
            runs.append({"set": s, "call": b["call"], "round": b["round"], "tid": b["tid"],
                         "cid": b["cid"], "model": b["meta"]["모델"], "time": b["meta"]["시각"],
                         "checks": checks, "rate": rate(checks),
                         "extra": score.extra_check(ek, task, resp) if ek else None})

    with open(out / "results_all.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["세트", "호출번호", "라운드", "과제", "조건", "조건명", "모델", "시각"]
                   + [f"지시{i}" for i in range(1, nrules + 1)] + ["준수율(%)", "추가지시"])
        for r in runs:
            w.writerow([r["set"], r["call"], r["round"], r["tid"], r["cid"], names[r["cid"]],
                        r["model"], r["time"]] + ["O" if c else "X" for c in r["checks"]]
                       + [f"{r['rate']:.1f}", "" if r["extra"] is None else ("O" if r["extra"] else "X")])

    # 셀 = (세트, 라운드). 라운드마다 10개 조건이 같은 과제를 쓰므로 조건 간 비교는 셀 안에서 짝을 짓는다.
    cells = {(r["set"], r["round"], r["cid"]): r["checks"] for r in runs}
    keys = sorted({(s, rd) for s, rd, _ in cells})
    cids = [c["id"] for c in cfg["conditions"]]
    rng = random.Random(SEED)
    mean = {c: st.mean(rate(cells[(s, rd, c)]) for s, rd in keys) for c in cids}

    rows = []
    for c in cids:
        if c == "C00":
            continue
        d = [rate(cells[(s, rd, c)]) - rate(cells[(s, rd, "C00")]) for s, rd in keys]
        m = st.mean(d)
        bs = sorted(st.mean(rng.choices(d, k=len(d))) for _ in range(N_BOOT))
        lo, hi = bs[int(N_BOOT * 0.025)], bs[int(N_BOOT * 0.975)]
        p = sum(abs(st.mean([x * rng.choice((1, -1)) for x in d])) >= abs(m) - 1e-9
                for _ in range(N_PERM)) / N_PERM
        ex = [r["extra"] for r in runs if r["cid"] == c and r["extra"] is not None]
        rows.append({"cid": c, "name": names[c], "rate": mean[c], "diff": m, "lo": lo, "hi": hi,
                     "p": p, "up": sum(x > 0 for x in d), "down": sum(x < 0 for x in d),
                     "tie": sum(x == 0 for x in d),
                     "extra": (sum(ex) / len(ex) * 100) if ex else None})
    # Holm 보정
    order = sorted(range(len(rows)), key=lambda i: rows[i]["p"])
    prev = 0.0
    for rank_i, i in enumerate(order):
        adj = min(1.0, rows[i]["p"] * (len(rows) - rank_i))
        prev = max(prev, adj)
        rows[i]["p_holm"] = prev
    rows.sort(key=lambda r: -r["diff"])
    rank, prev_d = 0, None
    for i, r in enumerate(rows):
        if round(r["diff"], 1) != prev_d:
            rank = i + 1
        r["rank"], prev_d = rank, round(r["diff"], 1)
        r["flag10"] = "구분됨" if abs(r["diff"]) > THRESHOLD else "기본과 구분되지 않음"
        r["flagci"] = "구간이 0을 포함하지 않음" if (r["lo"] > 0 or r["hi"] < 0) else "구간이 0을 포함"

    with open(out / "summary_final.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["순위", "조건", "조건명", "횟수", "기본지시 준수율(%)", "기본 대비(%p)", "95%구간 하한",
                    "95%구간 상한", "순열 p", "Holm 보정 p", "개선 셀", "악화 셀", "동률 셀",
                    "10%p 기준", "신뢰구간 기준", "추가지시 준수율(%)"])
        w.writerow(["기준", "C00", "기본", len(keys), f"{mean['C00']:.1f}"] + [""] * 11)
        for r in rows:
            w.writerow([r["rank"], r["cid"], r["name"], len(keys), f"{r['rate']:.1f}", f"{r['diff']:+.1f}",
                        f"{r['lo']:+.1f}", f"{r['hi']:+.1f}", f"{r['p']:.3f}", f"{r['p_holm']:.3f}",
                        r["up"], r["down"], r["tie"], r["flag10"], r["flagci"],
                        "" if r["extra"] is None else f"{r['extra']:.0f}"])

    counts = {c: [sum(cells[(s, rd, c)][i] for s, rd in keys) for i in range(nrules)] for c in cids}
    with open(out / "per_rule.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["조건", "조건명"] + [f"지시{i+1} {RULE_SHORT[i]} 통과/{len(keys)}" for i in range(nrules)]
                   + ["기본과 달라진 지시(Fisher p<0.05, 보정 전)"])
        for c in cids:
            sig = []
            if c != "C00":
                for i in range(nrules):
                    p = fisher(counts[c][i], len(keys), counts["C00"][i], len(keys))
                    if p < 0.05:
                        sig.append(f"지시{i+1}({counts['C00'][i]}→{counts[c][i]}, p={p:.3f})")
            w.writerow([c, names[c]] + counts[c] + ["; ".join(sig)])

    per_task = {}
    for r in runs:
        per_task.setdefault((r["tid"], r["cid"] == "C00"), []).append(r["rate"])
    with open(out / "per_task.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["과제", "과제명", "기본 준수율(%)", "전체 조건 평균(%)"])
        for t in tasks:
            w.writerow([t, tasks[t]["name"], f"{st.mean(per_task[(t, True)]):.1f}",
                        f"{st.mean(per_task[(t, True)] + per_task[(t, False)]):.1f}"])

    print(f"유효 {len(runs)}건 / 조건당 {len(keys)}회 / 기본 {mean['C00']:.1f}%")
    print("순위 | 조건 | 준수율 | 기본 대비 | 95% 구간 | 순열 p | Holm p | 개선/악화")
    for r in rows:
        print(f"{r['rank']} | {r['cid']} {r['name']} | {r['rate']:.1f} | {r['diff']:+.1f} | "
              f"[{r['lo']:+.1f}, {r['hi']:+.1f}] | {r['p']:.3f} | {r['p_holm']:.3f} | {r['up']}/{r['down']}")

    try:
        make_figures(out, rows, mean, counts, cids, names, len(keys))
    except ImportError:
        print("matplotlib 이 없어 그래프는 만들지 않았습니다.")


def make_figures(out, rows, mean, counts, cids, names, n):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    from matplotlib.colors import LinearSegmentedColormap
    for fam in ("Noto Sans CJK KR", "Noto Sans KR", "Malgun Gothic", "AppleGothic", "NanumGothic", "Noto Sans CJK JP"):
        if any(fam == f.name for f in font_manager.fontManager.ttflist):
            plt.rcParams["font.family"] = fam
            break
    plt.rcParams["axes.unicode_minus"] = False
    ink, ink2, grid, accent, gray = "#0b0b0b", "#52514e", "#e6e5e1", "#2a78d6", "#a3a29c"

    # 그림 1: 기본 대비 차이와 95% 신뢰구간
    fig, ax = plt.subplots(figsize=(7.2, 4.2), dpi=200)
    rs = list(reversed(rows))
    ax.axvspan(-THRESHOLD, THRESHOLD, color=grid, alpha=0.55, lw=0)
    ax.axvline(0, color=ink2, lw=1)
    for i, r in enumerate(rs):
        hot = r["lo"] > 0 and r["p_holm"] < 0.05
        col = accent if hot else gray
        ax.plot([r["lo"], r["hi"]], [i, i], color=col, lw=2, solid_capstyle="round")
        ax.plot(r["diff"], i, "o", ms=8, color=col, mec="#fcfcfb", mew=1.5, zorder=3)
        ax.text(26, i, f"{r['diff']:+.1f}", va="center", ha="left", fontsize=9.5,
                color=ink if hot else ink2, fontweight="bold" if hot else "normal")
    ax.set_yticks(range(len(rs)))
    ax.set_yticklabels([r["name"] for r in rs], fontsize=9.5, color=ink)
    ax.set_xlabel("기본 조건 대비 준수율 차이 (%p)", fontsize=9.5, color=ink2)
    ax.set_xlim(-22, 32)
    ax.set_xticks([-20, -10, 0, 10, 20])
    ax.set_title(f"요소별 준수율 차이와 95% 신뢰구간 (조건당 {n}회, 회색 띠는 ±{THRESHOLD:.0f}%p)",
                 fontsize=10.5, color=ink, loc="left")
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    ax.tick_params(axis="y", length=0)
    ax.tick_params(axis="x", colors=ink2, labelsize=9)
    ax.grid(axis="x", color=grid, lw=0.6)
    ax.set_axisbelow(True)
    fig.tight_layout()
    fig.savefig(out / "fig1.png", facecolor="#fcfcfb")
    plt.close(fig)

    # 그림 2: 지시별 통과율 히트맵
    fig, ax = plt.subplots(figsize=(7.4, 4.6), dpi=200)
    cmap = LinearSegmentedColormap.from_list("blue", ["#eef4fc", "#9ec3ee", "#2a78d6", "#14447f"])
    data = [[counts[c][i] / n * 100 for i in range(len(RULE_SHORT))] for c in cids]
    im = ax.imshow(data, cmap=cmap, vmin=0, vmax=100, aspect="auto")
    for y, row in enumerate(data):
        for x, v in enumerate(row):
            ax.text(x, y, f"{v:.0f}", ha="center", va="center", fontsize=8.5,
                    color="#ffffff" if v >= 62 else ink)
    ax.set_xticks(range(len(RULE_SHORT)))
    ax.set_xticklabels(RULE_SHORT, fontsize=8.5, rotation=28, ha="right", color=ink)
    ax.set_yticks(range(len(cids)))
    ax.set_yticklabels([names[c] for c in cids], fontsize=9, color=ink)
    ax.tick_params(length=0)
    for s in ax.spines.values():
        s.set_visible(False)
    ax.set_title("조건별·지시별 통과율 (%)", fontsize=10.5, color=ink, loc="left")
    fig.tight_layout()
    fig.savefig(out / "fig2.png", facecolor="#fcfcfb")
    plt.close(fig)


if __name__ == "__main__":
    main()
