"""run_sheet.txt 의 빈 응답을 Gemini API 로 자동으로 채웁니다.

사용법
  1) 키 설정   (macOS/Linux)  export GEMINI_API_KEY="발급받은키"
               (Windows PS)   $env:GEMINI_API_KEY="발급받은키"
  2) 모델 목록  python run_gemini.py --list-models
  3) 실행       python run_gemini.py --model 모델ID
     일부만     python run_gemini.py --model 모델ID --only C00
     개수 제한  python run_gemini.py --model 모델ID --limit 3

이미 응답이 채워진 블록은 건너뛰므로, 중간에 멈춰도 다시 실행하면 이어서 합니다.
한 호출은 한 개의 메시지만 보내는 독립 호출입니다(대화 기록 없음).
"""
import argparse
import datetime
import json
import os
import pathlib
import re
import sys
import time
import urllib.error
import urllib.request

SHEET = pathlib.Path("run_sheet.txt")
PLACEHOLDER = "(여기에 응답 붙여넣기)"
HEADER = re.compile(r"^=== (\d+) \| 라운드 (\d+) \| (T\d\d) \| ([A-Z]\d+) \| (.+) ===$")
BASE = "https://generativelanguage.googleapis.com/v1beta"


def api(path, key, body=None):
    req = urllib.request.Request(
        f"{BASE}/{path}", headers={"x-goog-api-key": key, "Content-Type": "application/json"},
        data=None if body is None else json.dumps(body).encode("utf-8"))
    with urllib.request.urlopen(req, timeout=180) as r:
        return json.loads(r.read().decode("utf-8"))


def list_models(key):
    for m in api("models?pageSize=200", key).get("models", []):
        if "generateContent" in m.get("supportedGenerationMethods", []):
            print(m["name"].split("/", 1)[1], "|", m.get("displayName", ""))


def generate(model, prompt, key, retries=3):
    body = {"contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": {"maxOutputTokens": 32768}}
    wait = 20
    for _ in range(retries):
        try:
            d = api(f"models/{model}:generateContent", key, body)
            cands = d.get("candidates") or []
            if not cands:
                return None, "응답 없음: " + json.dumps(d.get("promptFeedback", d), ensure_ascii=False)
            parts = cands[0].get("content", {}).get("parts", [])
            text = "".join(p.get("text", "") for p in parts if not p.get("thought"))
            return text.strip(), cands[0].get("finishReason", "")
        except urllib.error.HTTPError as e:
            msg = e.read().decode("utf-8", "replace")[:1500]
            if e.code == 429 and re.search(r"PerDay|per day|RequestsPerDay", msg, re.I):
                return None, "하루 한도(RPD) 초과: 재시도하지 않고 멈춥니다. 한도가 풀린 뒤 다시 실행하세요."
            if e.code in (429, 500, 503):
                print(f"  {e.code} - {wait}초 후 재시도", flush=True)
                time.sleep(wait)
                wait = min(wait * 2, 120)
                continue
            return None, f"HTTP {e.code}: {msg}"
        except Exception as e:
            print(f"  오류 {e} - {wait}초 후 재시도", flush=True)
            time.sleep(wait)
            wait = min(wait * 2, 120)
    return None, "재시도 초과"


def split_blocks(lines):
    idx = [i for i, l in enumerate(lines) if HEADER.match(l)]
    return [(s, e) for s, e in zip(idx, idx[1:] + [len(lines)])]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model")
    ap.add_argument("--only", help="조건 ID (예: C00)")
    ap.add_argument("--limit", type=int)
    ap.add_argument("--pause", type=float, default=6.0, help="호출 사이 대기(초)")
    ap.add_argument("--list-models", action="store_true")
    a = ap.parse_args()
    key = os.environ.get("GEMINI_API_KEY")
    if not key:
        sys.exit("GEMINI_API_KEY 환경변수가 없습니다.")
    if a.list_models:
        return list_models(key)
    if not a.model:
        sys.exit("--model 이 필요합니다. (--list-models 로 확인)")
    lines = SHEET.read_text(encoding="utf-8").split("\n")
    n = 0
    while True:
        target = None
        for s, e in split_blocks(lines):
            m = HEADER.match(lines[s])
            blk = lines[s:e]
            if a.only and m.group(4) != a.only:
                continue
            ri = blk.index("--- 응답 ---")
            resp = "\n".join(blk[ri + 1:]).strip()
            if resp in ("", PLACEHOLDER):
                target = (s, e, ri, m)
                break
        if not target or (a.limit and n >= a.limit):
            break
        s, e, ri, m = target
        blk = lines[s:e]
        pi = blk.index("--- 프롬프트 ---")
        prompt = "\n".join(blk[pi + 1:ri]).strip()
        print(f"[{m.group(1)}] 라운드 {m.group(2)} {m.group(3)} {m.group(4)} 호출 중...", flush=True)
        text, info = generate(a.model, prompt, key)
        if not text:
            print(f"  실패: {info} - 중단합니다. 다시 실행하면 이어서 합니다.")
            break
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        for j, l in enumerate(blk):
            if l.startswith("모델:"):
                blk[j] = f"모델: {a.model}"
            elif l.startswith("시각:"):
                blk[j] = f"시각: {now}"
        lines[s:e] = blk[:ri + 1] + text.split("\n") + [""]
        SHEET.write_text("\n".join(lines), encoding="utf-8")
        n += 1
        print(f"  완료 ({len(text)}자, 종료사유 {info})", flush=True)
        time.sleep(a.pause)
    print(f"이번 실행에서 {n}건 저장")


if __name__ == "__main__":
    main()
