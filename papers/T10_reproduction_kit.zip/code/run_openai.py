"""run_sheet.txt 의 빈 응답을 OpenAI API(Responses API)로 자동으로 채웁니다.

사용법
  1) 키 설정   (macOS/Linux)  export OPENAI_API_KEY="발급받은키"
               (Windows PS)   $env:OPENAI_API_KEY="발급받은키"
  2) 실행       python run_openai.py --model gpt-5.6-luna
     개수 제한  python run_openai.py --model gpt-5.6-luna --limit 3

이미 응답이 채워진 블록은 건너뛰므로, 중간에 멈춰도 다시 실행하면 이어서 합니다.
한 호출은 한 개의 메시지만 보내는 독립 호출입니다(대화 기록 없음). 추론 강도 등 다른 설정은 기본값 그대로 둡니다.
"""
import argparse
import datetime
import json
import os
import pathlib
import re
import sys
import time
import urllib.error
import urllib.request

SHEET = pathlib.Path("run_sheet.txt")
PLACEHOLDER = "(여기에 응답 붙여넣기)"
HEADER = re.compile(r"^=== (\d+) \| 라운드 (\d+) \| (T\d\d) \| ([A-Z]\d+) \| (.+) ===$")
URL = "https://api.openai.com/v1/responses"


def generate(model, prompt, key, retries=3):
    body = {"model": model, "input": prompt, "max_output_tokens": 32000}
    wait = 20
    for _ in range(retries):
        try:
            req = urllib.request.Request(
                URL, headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                data=json.dumps(body).encode("utf-8"))
            with urllib.request.urlopen(req, timeout=300) as r:
                d = json.loads(r.read().decode("utf-8"))
            text = "".join(c.get("text", "") for o in d.get("output", []) if o.get("type") == "message"
                           for c in o.get("content", []) if c.get("type") == "output_text").strip()
            if not text:
                return None, "응답 없음: " + json.dumps(d.get("incomplete_details") or d.get("error") or d.get("status"), ensure_ascii=False)
            return text, d.get("status", "")
        except urllib.error.HTTPError as e:
            msg = e.read().decode("utf-8", "replace")[:1500]
            if e.code == 429 and re.search(r"insufficient_quota", msg):
                return None, "크레딧 부족(insufficient_quota): 충전 상태를 확인하세요."
            if e.code in (429, 500, 502, 503):
                print(f"  {e.code} - {wait}초 후 재시도", flush=True)
                time.sleep(wait)
                wait = min(wait * 2, 120)
                continue
            return None, f"HTTP {e.code}: {msg}"
        except Exception as e:
            print(f"  오류 {e} - {wait}초 후 재시도", flush=True)
            time.sleep(wait)
            wait = min(wait * 2, 120)
    return None, "재시도 초과"


def split_blocks(lines):
    idx = [i for i, l in enumerate(lines) if HEADER.match(l)]
    return [(s, e) for s, e in zip(idx, idx[1:] + [len(lines)])]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model")
    ap.add_argument("--only", help="조건 ID (예: C00)")
    ap.add_argument("--limit", type=int)
    ap.add_argument("--pause", type=float, default=2.0, help="호출 사이 대기(초)")
    a = ap.parse_args()
    key = (os.environ.get("OPENAI_API_KEY") or "").strip().strip('"').strip("'")
    if not key:
        sys.exit("OPENAI_API_KEY 환경변수가 없습니다.")
    if not (key.isascii() and key.isprintable() and " " not in key):
        sys.exit("OPENAI_API_KEY 값에 한글·공백·줄바꿈 등 키에 쓸 수 없는 문자가 있습니다. "
                 "예시 문구가 아니라 발급받은 실제 키(sk-...)만 따옴표 안에 넣어 다시 설정하세요.")
    if not a.model:
        sys.exit("--model 이 필요합니다. (예: gpt-5.6-luna)")
    lines = SHEET.read_text(encoding="utf-8").split("\n")
    n = 0
    while True:
        target = None
        for s, e in split_blocks(lines):
            m = HEADER.match(lines[s])
            blk = lines[s:e]
            if a.only and m.group(4) != a.only:
                continue
            ri = blk.index("--- 응답 ---")
            resp = "\n".join(blk[ri + 1:]).strip()
            if resp in ("", PLACEHOLDER):
                target = (s, e, ri, m)
                break
        if not target or (a.limit and n >= a.limit):
            break
        s, e, ri, m = target
        blk = lines[s:e]
        pi = blk.index("--- 프롬프트 ---")
        prompt = "\n".join(blk[pi + 1:ri]).strip()
        print(f"[{m.group(1)}] 라운드 {m.group(2)} {m.group(3)} {m.group(4)} 호출 중...", flush=True)
        text, info = generate(a.model, prompt, key)
        if not text:
            print(f"  실패: {info} - 중단합니다. 다시 실행하면 이어서 합니다.")
            break
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        for j, l in enumerate(blk):
            if l.startswith("모델:"):
                blk[j] = f"모델: {a.model}"
            elif l.startswith("시각:"):
                blk[j] = f"시각: {now}"
        lines[s:e] = blk[:ri + 1] + text.split("\n") + [""]
        SHEET.write_text("\n".join(lines), encoding="utf-8")
        n += 1
        print(f"  완료 ({len(text)}자, 종료사유 {info})", flush=True)
        time.sleep(a.pause)
    print(f"이번 실행에서 {n}건 저장")


if __name__ == "__main__":
    main()
