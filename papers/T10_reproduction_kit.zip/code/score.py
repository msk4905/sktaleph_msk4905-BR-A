import csv
import json
import pathlib
import re
import sys

SHEET = pathlib.Path("run_sheet.txt")
CONFIG = pathlib.Path("conditions.json")
PLACEHOLDER = "(여기에 응답 붙여넣기)"
THRESHOLD = 10.0

EMOJI = re.compile("[\U0001F000-\U0001FAFF☀-➿⬀-⯿️]")
HEADER = re.compile(r"^=== (\d+) \| 라운드 (\d+) \| (T\d\d) \| ([A-Z]\d+) \| (.+) ===$")


def parse(text):
    blocks, cur = [], None
    for line in text.splitlines():
        m = HEADER.match(line)
        if m:
            if cur:
                blocks.append(cur)
            cur = {"call": int(m.group(1)), "round": int(m.group(2)),
                   "tid": m.group(3), "cid": m.group(4), "name": m.group(5), "lines": []}
        elif cur is not None:
            cur["lines"].append(line)
    if cur:
        blocks.append(cur)
    for b in blocks:
        body = b.pop("lines")
        meta = {"모델": "", "전환안내": "", "시각": ""}
        resp, mode = [], "meta"
        for line in body:
            if mode == "meta":
                if line.strip() == "--- 프롬프트 ---":
                    mode = "prompt"
                    continue
                for k in meta:
                    if line.startswith(k + ":"):
                        meta[k] = line.split(":", 1)[1].strip()
            elif mode == "prompt":
                if line.strip() == "--- 응답 ---":
                    mode = "resp"
            else:
                resp.append(line)
        b["meta"] = meta
        b["response"] = "\n".join(resp).strip()
    return blocks


def ns(t):
    return re.sub(r"\s+", "", t)


def collapse(t):
    return re.sub(r"[ \t]+", " ", t)


def nonblank(t):
    return [l for l in t.splitlines() if l.strip()]


def clean(line):
    return line.replace("**", "").strip()


def first_line(t):
    for line in t.splitlines():
        if line.strip():
            return re.sub(r"^[\s#*\-•·>]+|[\s*]+$", "", line)
    return ""


def last_line(t):
    for line in reversed(nonblank(t)):
        rest = " ".join(tok for tok in line.split() if not tok.startswith("#"))
        if re.sub(r"[^\w]", "", rest):
            return line
    return ""


def sentences(t):
    out = []
    for part in re.split(r"(?<=[.!?])\s+|\n+", t):
        s = re.sub(r"^\s*[-*•·■①②③\d.]*\s*", "", clean(part)).strip()
        if s:
            out.append(s)
    return out


def starts(line, prefix):
    c = clean(line)
    if prefix not in ("-", "*", "•", "·"):
        c = c.lstrip("-*•· ")
    return c.startswith(prefix)



MARKS = ("▶", "■", "#", "-", "※")
PUNCT_END = re.compile(r"[.!?]['\")\]]*$")


def b_lines(t):
    return [l.strip().replace("**", "") for l in t.splitlines() if l.strip()]


def b_sents(t):
    out = []
    for l in b_lines(t):
        if l.startswith(MARKS) or not PUNCT_END.search(l):
            continue
        out += [x for x in re.split(r"(?<=[.!?])\s+", l) if x.strip()]
    return out


def b_blocks(t):
    out = []
    for b in re.split(r"\n\s*\n", t.strip()):
        ls = [l.strip().replace("**", "") for l in b.splitlines() if l.strip()]
        ls = [l for l in ls if not l.startswith(MARKS) and PUNCT_END.search(l)]
        ss = [x for l in ls for s0 in [l] for x in re.split(r"(?<=[.!?])\s+", s0) if x.strip()]
        if ss:
            out.append(ss)
    return out


def b_strip_end(x):
    return re.sub(r"[.!?'\")\]\s]+$", "", x)


def run_check(c, t):
    ty = c["type"]
    if ty == "first_line":
        return ns(first_line(t)) == ns(c["equals"])
    if ty == "contains_all":
        if c.get("nospace"):
            return all(ns(i) in ns(t) for i in c["items"])
        return all(i in collapse(t) for i in c["items"])
    if ty == "not_contains":
        return all(i not in t for i in c["items"])
    if ty == "no_emoji":
        return EMOJI.search(t) is None
    if ty == "no_emoji_exclaim":
        return EMOJI.search(t) is None and "!" not in t
    if ty == "max_sentence_len":
        return all(len(s) <= c["n"] for s in sentences(t))
    if ty == "last_line":
        ln = last_line(t)
        return any(w in ln for w in c["any"]) and not any(w in ln for w in c["none"])
    if ty == "prefix_count":
        ls = [l for l in t.splitlines() if starts(l, c["prefix"])]
        return len(ls) == c["n"] and all(i in collapse(t) for i in c["also"])
    if ty == "numbered_count":
        return len([l for l in t.splitlines() if re.match(r"\s*\d+[.)]\s", l)]) == c["n"]
    if ty == "labels_once":
        return all(len([l for l in t.splitlines() if starts(l, i)]) == 1 for i in c["items"])
    if ty == "ordered_prefixes":
        pos = []
        for i in c["items"]:
            idx = [k for k, l in enumerate(t.splitlines()) if starts(l, i)]
            if not idx:
                return False
            pos.append(idx[0])
        return pos == sorted(pos)
    if ty == "count_equals":
        return t.count(c["item"]) == c["n"]
    if ty == "max_sent_per_para":
        paras = [p for p in re.split(r"\n\s*\n", t.strip()) if p.strip()]
        return all(len(re.findall(r"[.!?]+(?=\s|$)", p)) <= c["n"] for p in paras)
    if ty == "no_haeyo":
        s = t.replace("안녕하세요", "")
        return re.search(r"(세요|해요|에요|예요|어요|아요)(?=[\s.!?,]|$)", s) is None
    if ty == "line_any":
        ls = nonblank(t)
        return len(ls) >= c["n"] and any(w in ls[c["n"] - 1] for w in c["any"])
    if ty == "chars_range":
        n = len(ns(t)) if c.get("nospace") else len(t)
        return c["min"] <= n <= c["max"]
    if ty == "max_para_lines":
        ps = [p for p in re.split(r"\n\s*\n", t.strip()) if p.strip()]
        return all(len([l for l in p.splitlines() if l.strip()]) <= c["n"] for p in ps)
    if ty == "max_line_len":
        return all(len(l.replace("**", "").strip()) <= c["n"] for l in t.splitlines())
    if ty == "no_repeat_ending":
        sents = [x.strip() for x in re.split(r"(?<=[.!?])\s+|\n+", t) if x.strip()]
        ends = [re.sub(r"[\s.!?*)\]]+$", "", x)[-2:] for x in sents]
        run = m = 1
        for i in range(1, len(ends)):
            run = run + 1 if ends[i] == ends[i - 1] else 1
            m = max(m, run)
        return m < c["n"]
    if ty == "blocks_equal":
        return len(b_blocks(t)) == c["n"]
    if ty == "first_block_sents":
        b = b_blocks(t)
        return bool(b) and len(b[0]) == c["n"]
    if ty == "block_sents_range":
        b = b_blocks(t)
        return bool(b) and all(c["min"] <= len(x) <= c["max"] for x in b)
    if ty == "sentences_range":
        return c["min"] <= len(b_sents(t)) <= c["max"]
    if ty == "all_end_yo":
        ss = b_sents(t)
        return bool(ss) and all(b_strip_end(x).endswith("요") for x in ss)
    if ty == "first_sentence_max":
        b = b_blocks(t)
        return bool(b) and len(b[0][0]) <= c["n"]
    if ty == "lines_min":
        return len(nonblank(t)) >= c["n"]
    if ty == "chars_min":
        n = len(ns(t)) if c.get("nospace") else len(t)
        return n >= c["min"]
    if ty == "lines_equal":
        return len(nonblank(t)) == c["n"]
    if ty == "sentences_equal":
        return len(re.findall(r"[.!?]+(?=\s|$)", t)) == c["n"]
    raise ValueError(ty)


def rule_pass(rule, t):
    return all(run_check(c, t) for c in rule["checks"])


def extra_check(kind, task, t):
    if kind == "bullets":
        return len([l for l in t.splitlines() if re.match(r"\s*[-*•·]\s+", l)]) >= 2
    if kind == "constraints":
        return "정말" not in t and "확인" in t
    if kind == "title_first":
        ls = nonblank(t)
        return bool(ls) and len(clean(ls[0])) <= 30 and not re.search(r"[.!?]$", clean(ls[0]))
    if kind == "length":
        return run_check(task["length"]["check"], t)
    raise ValueError(kind)


def yn(v):
    return "" if v is None else ("O" if v else "X")


def main():
    if not SHEET.exists():
        sys.exit("run_sheet.txt 가 없습니다.")
    cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
    names = {c["id"]: c["name"] for c in cfg["conditions"]}
    extras = {c["id"]: c.get("extra") for c in cfg["conditions"]}
    tasks = {t["id"]: t for t in cfg["tasks"]}
    nrules = len(cfg["tasks"][0]["rules"])
    blocks = parse(SHEET.read_text(encoding="utf-8"))

    rows = []
    for b in blocks:
        resp = b["response"]
        done = resp != "" and resp != PLACEHOLDER
        switched = b["meta"]["전환안내"] in ("예", "y", "Y", "yes")
        task = tasks[b["tid"]]
        row = {"call": b["call"], "round": b["round"], "tid": b["tid"], "cid": b["cid"],
               "name": names.get(b["cid"], b["name"]), "done": done,
               "valid": done and not switched, "model": b["meta"]["모델"],
               "time": b["meta"]["시각"], "checks": None, "rate": None, "extra": None}
        if done:
            checks = [rule_pass(r, resp) for r in task["rules"]]
            row["checks"] = checks
            row["rate"] = sum(checks) / nrules * 100
            ek = extras.get(b["cid"])
            if ek:
                row["extra"] = extra_check(ek, task, resp)
        rows.append(row)

    with open("results.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["호출번호", "라운드", "과제", "조건", "조건명", "유효", "모델", "시각"]
                   + [f"지시{i}" for i in range(1, nrules + 1)] + ["준수율(%)", "추가지시"])
        for r in rows:
            c = r["checks"] or [None] * nrules
            w.writerow([r["call"], r["round"], r["tid"], r["cid"], r["name"],
                        "O" if r["valid"] else "X", r["model"], r["time"],
                        *[yn(x) for x in c],
                        "" if r["rate"] is None else f"{r['rate']:.1f}",
                        yn(r["extra"])])

    summary = {}
    for c in cfg["conditions"]:
        vs = [r for r in rows if r["cid"] == c["id"] and r["valid"]]
        ex = [r["extra"] for r in vs if r["extra"] is not None]
        summary[c["id"]] = {
            "name": c["name"], "n": len(vs),
            "rate": sum(r["rate"] for r in vs) / len(vs) if vs else None,
            "extra": (sum(ex) / len(ex) * 100) if ex else None,
        }

    base = summary["C00"]["rate"]
    ranked = []
    if base is not None:
        for cid, s in summary.items():
            if cid != "C00" and s["rate"] is not None:
                s["diff"] = round(s["rate"] - base, 1)
                ranked.append((s["diff"], cid))
        ranked.sort(key=lambda x: -x[0])
    ranks, prev, rank = {}, None, 0
    for i, (d, cid) in enumerate(ranked):
        if d != prev:
            rank = i + 1
        ranks[cid], prev = rank, d

    with open("summary.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["순위", "조건", "조건명", "유효 횟수", "기본지시 준수율(%)",
                    "기본 대비 차이(%p)", "구분 여부", "추가지시 준수율(%)"])
        order = ["C00"] + [cid for _, cid in ranked]
        for cid in order:
            s = summary[cid]
            if cid == "C00":
                w.writerow(["기준", cid, s["name"], s["n"],
                            "" if s["rate"] is None else f"{s['rate']:.1f}", "", "", ""])
                continue
            flag = "기본과 구분되지 않음" if abs(s["diff"]) <= THRESHOLD else "구분됨"
            w.writerow([ranks[cid], cid, s["name"], s["n"], f"{s['rate']:.1f}",
                        f"{s['diff']:+.1f}", flag,
                        "" if s["extra"] is None else f"{s['extra']:.0f}"])
        for cid, s in summary.items():
            if cid not in order:
                w.writerow(["", cid, s["name"], s["n"], "", "", "유효 응답 없음", ""])

    print("순위 | 조건 | 유효 | 준수율 | 기본 대비 | 구분")
    print("기준 | C00 기본 | %d | %s" % (summary["C00"]["n"],
          "-" if base is None else f"{base:.1f}"))
    for d, cid in ranked:
        s = summary[cid]
        flag = "기본과 구분되지 않음" if abs(d) <= THRESHOLD else "구분됨"
        print(f"{ranks[cid]} | {cid} {s['name']} | {s['n']} | {s['rate']:.1f} | {d:+.1f}%p | {flag}")

    not_done = [r["call"] for r in rows if not r["done"]]
    switched = [r["call"] for r in rows if r["done"] and not r["valid"]]
    short = [cid for cid, s in summary.items() if s["n"] != cfg["rounds"]]
    models = {r["model"] for r in rows if r["done"]}
    print()
    if not_done:
        print(f"[경고] 응답이 비어 있는 호출 {len(not_done)}건")
    if switched:
        print(f"[제외] 모델 전환 안내가 뜬 호출 {len(switched)}건: {switched}")
    if short:
        print(f"[경고] 유효 응답이 {cfg['rounds']}회가 아닌 조건: {short}")
    if "" in models:
        print("[경고] 모델 이름이 비어 있는 호출이 있습니다.")
    if len(models - {""}) > 1:
        print(f"[경고] 모델 이름이 둘 이상 기록되었습니다: {sorted(models - {''})}")
    print("results.csv, summary.csv 저장 완료")


if __name__ == "__main__":
    main()
