import json
import pathlib
import random
import sys

CONFIG = pathlib.Path("conditions.json")
OUT = pathlib.Path("run_sheet.txt")
PLACEHOLDER = "(여기에 응답 붙여넣기)"


def chain(task, drop_key=False):
    return " ".join(r["chain"] for r in task["rules"] if not (drop_key and r.get("key")))


def build_prompt(task, cond, cfg=None):
    kind = cond["kind"]
    base = task["intro"] + " " + chain(task)
    if kind == "base":
        return base
    if kind in ("format", "constraint", "selfcheck"):
        return base + " " + cond["text"]
    if kind == "numbered":
        items = [f"{i}. {r['list']}" for i, r in enumerate(task["rules"], 1)]
        return task["intro"] + "\n" + "\n".join(items)
    if kind == "example":
        return base + "\n" + (cfg or {}).get("example_header", "예시:") + "\n" + task["example"]
    if kind == "role":
        return task["role"] + "\n" + base
    if kind == "length":
        return base + " " + task["length"]["text"]
    if kind == "key_first":
        return task["key_move"] + " " + task["intro"] + " " + chain(task, True)
    if kind == "key_last":
        return task["intro"] + " " + chain(task, True) + " " + task["key_move"]
    raise ValueError(kind)


def main():
    if OUT.exists():
        sys.exit("run_sheet.txt 가 이미 있어 덮어쓰지 않습니다.")
    cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
    conds = cfg["conditions"]
    tasks = cfg["tasks"]
    if cfg["rounds"] != len(tasks):
        sys.exit("라운드 수와 과제 수가 같아야 합니다.")
    rng = random.Random(cfg["seed"])
    lines = [
        f"# 고정 모델: {cfg['model']}",
        f"# 난수 시드: {cfg['seed']}",
        f"# 라운드 수: {cfg['rounds']} / 과제 수: {len(tasks)} / 조건 수: {len(conds)}",
        "",
    ]
    n = 0
    for r, task in enumerate(tasks, 1):
        order = conds[:]
        rng.shuffle(order)
        for c in order:
            n += 1
            lines += [
                f"=== {n:03d} | 라운드 {r} | {task['id']} | {c['id']} | {c['name']} ===",
                "모델: ",
                "전환안내: 아니오",
                "시각: ",
                "--- 프롬프트 ---",
                build_prompt(task, c, cfg),
                "--- 응답 ---",
                PLACEHOLDER,
                "",
            ]
    OUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"run_sheet.txt 생성: 총 {n}회")


if __name__ == "__main__":
    main()
